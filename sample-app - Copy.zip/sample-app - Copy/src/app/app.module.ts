import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import {RouterModule} from '@angular/router';
import { AppComponent } from './app.component';
import { WelcomeComponent} from './home/welcome.component';
import {SigninComponent} from './signin/signin.component';
import {AboutComponent} from './details/about.component';
import {CollectionComponent} from './collection/collection.component';
import {CarDetailComponent} from './car/car-details.component';
import {CarFilterPipe} from './car/car-filter.pipe';
import {RatingComponent} from './rating/rating.component';

@NgModule({
  declarations: [
    AppComponent,
   WelcomeComponent,
   SigninComponent,
   AboutComponent,
   CollectionComponent,
   CarDetailComponent,
   CarFilterPipe,
   RatingComponent
   ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
     RouterModule.forRoot([
        { path: 'welcome', component: WelcomeComponent },
        { path: 'about', component: AboutComponent },
        { path: 'signin', component: SigninComponent },
        { path: 'collections', component: CollectionComponent },
        {path : 'car/:id', component: CarDetailComponent},
      { path: '', redirectTo: 'welcome', pathMatch: 'full' },
      { path: '**', redirectTo: 'welcome', pathMatch: 'full' }
    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
