import {Component,OnInit} from '@angular/core';
@Component({
    templateUrl : 'collection.component.html',
    styleUrls : ['collection.component.css']

})
export class CollectionComponent implements OnInit{
pageTitle : string = 'Vintage Car Collection Data';
        imageWidth : number = 30;
        imageMargin : number = 1;
        listFilter :string = '';
        showImage : boolean = true;
cars : any[] = [
{
        "productId": 1,
        "productName": "Mercedes-Benz 300SL",
        "productCode": "GDN-0011",
        "releaseDate": "1955-1963",
        "description": "Old but gold",
        "price": 19.95,
        "starRating": 3.2,
        "imageUrl": "http://www.logodesignlove.com/images/evolution/mercedes-benz-logo-design.jpg"
    },
    {
        "productId": 2,
        "productName": "Citroen DS",
        "productCode": "GDN-0023",
        "releaseDate": "C1955-1975",
        "description": "classic sports car",
        "price": 32.99,
        "starRating": 4.2,
        "imageUrl": "http://www.titanui.com/wp-content/uploads/2013/12/04/Citroen-DS-Spirit-Logo-Vector.jpg"
    },
    {
        "productId": 5,
        "productName": "Lambhorgini Countach",
        "productCode": "TBX-0048",
        "releaseDate": "1974-1989",
        "description": " Mid-size luxury car",
        "price": 8.9,
        "starRating": 4.8,
        "imageUrl": "http://www.carlogos.org/logo/Lamborghini-logo.jpg"
    },
    {
        "productId": 8,
        "productName": "Lincoln Continental",
        "productCode": "TBX-0022",
        "releaseDate": "1961-1969",
        "description": "15-inch steel blade hand saw",
        "price": 11.55,
        "starRating": 3.7,
        "imageUrl": "https://images-na.ssl-images-amazon.com/images/I/218FiSAg5oL.jpg"
    },
    {
        "productId": 10,
        "productName": "Toyota 2000GT",
        "productCode": "GMG-0042",
        "releaseDate": "1967-1970",
        "description": "Standard two-button video game controller",
        "price": 35.95,
        "starRating": 4.6,
        "imageUrl": "https://www.brandsoftheworld.com/sites/default/files/styles/logo-thumbnail/public/012013/toyota_logo.jpg?itok=yfl9AHqs"
    }
];
toggleImage(): void {
    this.showImage = !this.showImage
}
ngOnInit(): void{
    console.log('In OnInit');
}
}