// An interface is a specification identifying a related set of properties and methods

// A class commits to supporting the specification by implementing the interface

//We can use the interface as datatype

//Development time only !


export interface IProduct {
    "productId": number,
        "productName": string,
        "productCode": string,
        "releaseDate": string,
        "description": string,
        "price": number,
        "starRating": number,
        "imageUrl":string
}