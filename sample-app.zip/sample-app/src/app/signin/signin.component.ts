import { Component } from '@angular/core';

import {Registration} from '../models/register.model';

@Component({
  templateUrl:`./signin.component.html`,
  styleUrls : ['./signin.component.css']
 
})
export class SigninComponent {
    signin : string = "Register";
    languages = ['English','Spanish','Other'];
    model = new Registration('','',false,'','default');
    hasPrimaryLangError = false;

    validatePrimaryLang (value){
     if(value === 'default')
     this.hasPrimaryLangError = true;
     else
     this.hasPrimaryLangError = false;
    
    }
}
