import { Component} from '@angular/core';

@Component({
  templateUrl:`./car-details.component.html`,
  styleUrls : ['./car-details.component.css']
 
})
export class CarDetailComponent {
    title : string = "Car Details"
}
