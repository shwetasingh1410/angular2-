import {Component} from '@angular/core';
@Component({

})
export class Registration {
    constructor(
        public firstName : string,
        public lastName : string,
        public isFulltime : boolean,
        public paymentType : string,
        public primaryLang : string
    )
    {
       
    }
}