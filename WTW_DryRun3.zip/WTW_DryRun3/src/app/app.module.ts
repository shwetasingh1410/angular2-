import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { AppComponent } from './app.component';
import { SidenavComponent } from './sidenav/sidenav.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';
import { FooterComponent } from './footer/footer.component';
import { RatingsComponent } from './ratings/ratings.component';
import { routing } from './routing';
import { DisclaimersComponent } from './disclaimers/disclaimers.component';
import { EdituserComponent } from './edituser/edituser.component';
import { AnnouncementsComponent } from './announcements/announcements.component';
import { UsersidenavComponent } from './usersidenav/usersidenav.component';
import { CarriersearchComponent } from './carriersearch/carriersearch.component';

@NgModule({
  declarations: [
    AppComponent,
    SidenavComponent,
    HeaderComponent,
    HomeComponent,
    FooterComponent,
    RatingsComponent,
    DisclaimersComponent,
    EdituserComponent,
    AnnouncementsComponent,
    UsersidenavComponent,
    CarriersearchComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    routing
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
