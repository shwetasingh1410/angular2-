import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-disclaimers',
  templateUrl: './disclaimers.component.html',
  styleUrls: ['./disclaimers.component.css']
})
export class DisclaimersComponent implements OnInit {
  text: string;
  constructor() { 
    this.text="I am in S & P";
  }

  ngOnInit() {
  }

  reloadcontent(data){
    if(data=='S & P'){
      this.text="I am in S & P";
    }
    if(data=="Moody's"){
      this.text="I am in Moody's";
    }
    if(data=='Fitch'){
      this.text="I am in Fitch";
    }
    if(data=='A.M.BEST'){
      this.text="I am in A.M.BEST";
    }
  }

}
