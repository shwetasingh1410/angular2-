import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
 active='Market Security';
  passive='Market Security Admin';
  isAdminActive=false;
  isUserActive=true;

  activeComp(data){
    console.log(data);
    if(data=='Market Security Admin'){
      this.active='Market Security Admin';
      this.passive='Market Security';
      this.isAdminActive=true;
      this.isUserActive=false;
    }
    else {
      this.passive='Market Security Admin';
      this.active='Market Security';
      this.isAdminActive=false;
    this.isUserActive=true;
    }
  }
}
