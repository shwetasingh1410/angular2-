import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-carriersearch',
  templateUrl: './carriersearch.component.html',
  styleUrls: ['./carriersearch.component.css']
})
export class CarriersearchComponent implements OnInit {
isClientSelected=false;
isTableSelected=false;
  constructor() { }

  ngOnInit() {
  }

  selectclient() {
    this.isClientSelected=true;
    this.isTableSelected=false;
  }

  findresults(){
    this.isTableSelected=true;
  }

}
