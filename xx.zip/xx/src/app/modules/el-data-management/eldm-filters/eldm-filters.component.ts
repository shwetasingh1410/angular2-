import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'eldm-filters',
  templateUrl: './eldm-filters.component.html',
  styleUrls: ['./eldm-filters.component.css']
})

export class ELDMFiltersComponent implements OnInit {


  yearList:any=['1972','1973','1974','1980','1985','1990','1995','2000','2005','2010','2015','2018'];
  monthList:any=['January','February','March','April','June','July','August','September','October','November','December'];
  selectedMonth:string='All Months';
  locationList:any=['Africa','Asia'];

  constructor() {
  }
  ngOnInit() {
  }
}
