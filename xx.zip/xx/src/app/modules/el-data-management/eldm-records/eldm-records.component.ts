import { Component, OnInit } from '@angular/core';
import { LossDataSubmissionModel } from '../../validate-loss-data-submission/shared/models/lossDataSubmission.model';
import * as _ from 'lodash';
@Component({
  selector: 'eldm-records',
  templateUrl: './eldm-records.component.html',
  styleUrls: ['./eldm-records.component.css'],
})

export class ELDMRecordsComponent implements OnInit {
  
  currentPageIndex:number=1;
lossDataSubmission:any=[];  
public lossDataSubmissionData = [
  { subId: '12345', referenceFile: '21242', customerName: 'British Petroleum', lossType: 'UpStream', submittedBy: 'John Davis', Date: '25-Apr-2018 13:05', Status: 'Approved', ReviewDate: '25-Apr-2018', StatusComment: 'All Information Valid' },
  { subId: '56524', referenceFile: '32312', customerName: 'Austria Oil and Gas', lossType: 'UpStream', submittedBy: 'John Davis', Date: '30-Apr-2018 13:10', Status: 'Approved', ReviewDate: '25-Apr-2018', StatusComment: 'Information not valid for further actions' },
   { subId: '32123', referenceFile: '54542', customerName: 'American Oil Inc.', lossType: 'Downstream', submittedBy: 'John Davis', Date: '30-Apr-2018 15:30', Status: 'Approved', ReviewDate: '25-Apr-2018', StatusComment: 'Not Valid Loss Type' },
  // { subId: '87872', referenceFile: '29876', customerName: 'British Petroleum', lossType: 'Power', submittedBy: 'John Davis', Date: '30-Apr-2018 09:30', Status: 'Approved', ReviewDate: '25-Apr-2018', StatusComment: 'Need More Information' },
  // { subId: '98981', referenceFile: '98262', customerName: 'British Petroleum', lossType: 'Power', submittedBy: 'John Davis', Date: '30-Apr-2018 10:45', Status: 'Approved', ReviewDate: '25-Apr-2018', StatusComment: 'Need More Information' },
  // { subId: '76767', referenceFile: '64528', customerName: 'British Oil Inc.', lossType: 'UpStream', submittedBy: 'John Davis', Date: '30-Apr-2018 14:45', Status: 'Approved', ReviewDate: '25-Apr-2018', StatusComment: 'Valid' },
  // { subId: '12332', referenceFile: '19092', customerName: 'Antar Petroleum', lossType: 'UpStream', submittedBy: 'John Davis', Date: '30-Apr-2018 15:30', Status: 'Approved', ReviewDate: '25-Apr-2018', StatusComment: 'Not Valid Loss Type' },
  // { subId: '24314', referenceFile: '67261', customerName: 'British Petroleum', lossType: 'Downstream', submittedBy: 'John Davis', Date: '30-Apr-2018 13:50', Status: 'Approved', ReviewDate: '25-Apr-2018', StatusComment: 'Need More Information' },
  // { subId: '87171', referenceFile: '19802', customerName: 'British Oil and Gas', lossType: 'UpStream', submittedBy: 'John Davis', Date: '30-Apr-2018 17:30', Status: 'Approved', ReviewDate: '25-Apr-2018', StatusComment: 'Need More Information' },
  // { subId: '32123', referenceFile: '54542', customerName: 'Columbia Oil Inc.', lossType: 'Downstream', submittedBy: 'John Davis', Date: '30-Apr-2018 19:30', Status: 'Approved', ReviewDate: '25-Apr-2018', StatusComment: 'Information Done and Verified' },
  // { subId: '87872', referenceFile: '29876', customerName: 'Canada Petroleum', lossType: 'Power', submittedBy: 'John Davis', Date: '30-Apr-2018 16:00', Status: 'Approved', ReviewDate: '25-Apr-2018', StatusComment: 'Information not valid' },
  // { subId: '98981', referenceFile: '98262', customerName: 'British Petroleum', lossType: 'Power', submittedBy: 'John Davis', Date: '30-Apr-2018 17:40', Status: 'Approved', ReviewDate: '25-Apr-2018', StatusComment: 'Information corrected but not verified' }

];


  isEditOn:boolean=false;

  isDeleted:boolean=false;

  isUpdated:Boolean=false;

  constructor(private lossDataSubmissionModel:LossDataSubmissionModel) {
  }

  ngOnInit() {
  }

  onPageChange($event) {
    this.lossDataSubmission=$event;
    this.lossDataSubmissionModel.setValidationFormType(this.lossDataSubmission[0].lossType);
    this.lossDataSubmissionModel.setSubscriptionID(this.lossDataSubmission[0].subId);
    this.lossDataSubmissionModel.setStatus(this.lossDataSubmission[0].Status);
  }

  onReportTypeChange() {

  }

  onEdit() {
    this.isEditOn=true;
  }

  showDeleteConfirmationModal() {
    document.getElementById('deleteConfirmationModalButton').click();
  }

  showDeleteSuccessModal() {
    document.getElementById('deleteSuccessModalButton').click();
  }

  onDelete() {
    let index= _.findIndex(this.lossDataSubmissionData,(obj)=>{return obj==this.lossDataSubmission[0]})
      if(index != -1) {
      this.lossDataSubmissionData.splice(index,1);
      this.isDeleted=true;
      let lossDataSubmission:any=[];
      if(index<(this.lossDataSubmissionData.length -1)){
        if(index != (this.lossDataSubmissionData.length -1)) { 
          lossDataSubmission[0]=this.lossDataSubmissionData[index];
          this.onPageChange(lossDataSubmission);
          this.isEditOn=false;
          this.showDeleteSuccessModal();
          }else {
            lossDataSubmission[0]=this.lossDataSubmissionData[this.lossDataSubmissionData.length-1];
          this.onPageChange(lossDataSubmission);
          this.isEditOn=false;
          this.showDeleteSuccessModal();
          }
      }else{
        lossDataSubmission[0]=this.lossDataSubmissionData[this.lossDataSubmissionData.length-1];
          this.onPageChange(lossDataSubmission);
          this.isEditOn=false;
          this.showDeleteSuccessModal();
      }
      
    }
  }

  onCancel() {
    this.isEditOn=false;
    window.scrollTo(0, 0);
  }

}
