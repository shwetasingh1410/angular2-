import { Component, OnInit, DoCheck } from '@angular/core';
import { Router } from "@angular/router";
import * as _ from 'lodash';
import { InMemoryStorageService } from '../../shared/storage/in-memory-storage.service';
import { ELDMReportFilters } from "./eldm-report-filters.const";
import { ELReportConfiguration } from './eldm-report.configuration';
import { ReportViewer } from '../reports/shared/report-viewer/report-viewer';
import { ReportViewerModel } from '../reports/shared/report-viewer/report-viewer.model';

@Component({
  selector: 'app-eldm',
  templateUrl: './el-data-management.component.html',
  styleUrls: ['./el-data-management.component.css'],
})

export class ELDataManagementComponent implements OnInit,DoCheck {

  isCaretToggle:boolean=true;

  reportItems:any='';
  isSearchTriggered:boolean;
  selectedReportName:string;
  isSearchOn:boolean;
  currentDate:Date=new Date();
  selectedReportConfiguration:any={};
  reportTypes:any=ELDMReportFilters;
  private allTableItems: ReportViewer;
  private reportViewerModel: ReportViewerModel;
  
  sortOrderList:any=[];



  constructor(private router:Router,private inMemoryStorage: InMemoryStorageService) {
  this.reportViewerModel=new ReportViewerModel();
  }
  ngOnInit() {
   

  }

  ngDoCheck() {
    
    $(document).ready(function(){
      (<any>$('[data-toggle="tooltip"]')).tooltip(); 
      (<any>$('[data-toggle="popover"]')).popover();  
  });
  }

  onSearch() {
    this.isSearchOn=true;
    this.selectedReportName='';
    this.isSearchTriggered=true;
    if(!this.isCaretToggle) {
      document.getElementById('recordFilters').click();
    }
  }

  onReset() {
    this.isSearchOn=false;
    this.selectedReportName='';
    this.isSearchTriggered=false;
    this.sortOrderList=[];
    if(!this.isCaretToggle) {
      document.getElementById('recordFilters').click();
    }
  }

  onEdit() {

  }

  onDelete() {

  }

  redirectToSearchPage() {
    this.onSearch();
  }

  onReportTypeChange(value) {
    this.selectedReportConfiguration = _.find(ELReportConfiguration, (e) => value.toLowerCase().includes(e.reportName.toLowerCase()));
    this.reportItems = _.orderBy(this.inMemoryStorage.getItem("OverallLossReportItems"), [this.selectedReportConfiguration.columns[0].key, "dateOfLoss"], ["asc", "desc"])
    // this.isSearchOn=false;
    this.selectedReportName=this.selectedReportConfiguration.reportName;
    this.allTableItems = this.reportViewerModel.generateReport(this.reportItems, this.selectedReportConfiguration);
    
    setTimeout(() => { document.getElementById('exportModal').click(); }, 1000);
  }
}
