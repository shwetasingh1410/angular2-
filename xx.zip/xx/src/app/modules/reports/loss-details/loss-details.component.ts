import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router'
import { InMemoryStorageService } from '../../../shared/storage/in-memory-storage.service';
import { LocalWebStorageService } from '../../../shared/storage/local-web-storage.service';
import { ReportResponse } from '../../reports/entities/report.response';

@Component({
    templateUrl: './loss-details.component.html',
    styleUrls: ['./loss-details.component.css']
})
export class LossDetailsComponent {

    reportDetail: ReportResponse = new ReportResponse(null, null, null,null,null,null,null,null,null,null,null,
        null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,
        null,null,null,null, null, null);

    currentDate: Date = new Date();

    constructor(private inMemoryStorage: InMemoryStorageService, private localWebStorage: LocalWebStorageService, private router: Router) {
    }

    ngOnInit() {
        this.reportDetail = this.inMemoryStorage.getItem("lossDetails");
    }

    goToReport() {
        this.localWebStorage.set("selectedReportName", this.inMemoryStorage.getItem("selectedReportName"));        
        this.localWebStorage.set("currentReportPageIndex", this.inMemoryStorage.getItem("currentReportPageIndex"));
        this.inMemoryStorage.setItem("lossDetails", null);
        let url = this.localWebStorage.get<string>("returnToReportUrl");
        this.localWebStorage.remove("returnToReportUrl");
        this.router.navigate([url]);
    }
}