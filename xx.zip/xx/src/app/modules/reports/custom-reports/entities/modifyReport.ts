import { ReportParameters } from "./reportParameters";

export class ModifyReport{ 
    
    id:string;
    reportCriteria:ReportParameters[];
}