import { ReportParameters } from "./reportParameters";

export class SaveReport{

    reportName:string;
    reportCriteria:ReportParameters[];

}