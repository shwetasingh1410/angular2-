import { ReportParameters } from "./reportParameters";

export class Report{
    
id:string;
reportName:string;
reportCriteria:ReportParameters[];

}