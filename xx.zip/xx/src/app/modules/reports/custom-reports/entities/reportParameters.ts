export class ReportParameters{
    displayName:string;
    columnName:string
}