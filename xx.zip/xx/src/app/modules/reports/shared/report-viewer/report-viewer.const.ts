export const ReportViewerConstant = {
    GroupRow: "GroupRow",
    DetailRow: "DetailRow",
    TotalRow: "TotalRow",
}