import { Component, OnInit, ViewChild, ElementRef, AfterViewInit } from "@angular/core";
import { Chart } from 'highcharts';
import { LossDataDashboardService } from "../../loss-data-dashboard.service";
import { ChartFilter } from "../../entities/chart-filter";
import { ChartData } from "../../../../user-controls/chart/entities/chart-data";

@Component({
    selector: 'incident-by-year-small-chart',
    templateUrl: './incident-by-year-small-chart.component.html',
    styleUrls: ['./incident-by-year-small-chart.component.css']
})

export class IncidentByYearSmallChartComponent implements OnInit {

    chartData: ChartData;

    constructor(private lossDataDashboardService: LossDataDashboardService) {
    }

    ngOnInit() {
        this.getIncidentByYear();
    }

    onExpand(){
        document.getElementById("incidentByYearBtn").click();    
    }
    
    private getIncidentByYear() {

        let chartFilter = new ChartFilter();
            chartFilter.fromYear = (new Date().getFullYear() - 10).toString(),
            chartFilter.toYear= new Date().getFullYear().toString(),
            chartFilter.areaId= null,
            chartFilter.upDownPowerStreamId= null
        

        this.lossDataDashboardService.getIncidentByYear(chartFilter)
            .subscribe((response) => {
                this.chartData = response;
                this.chartData.xAxisTitle = "Years";
                this.chartData.yAxisTitle = "Number Of Incidents";
            });
    }
}