import { Component, OnInit, ViewChild, ElementRef, Output, EventEmitter } from '@angular/core';
import { loadModules } from 'esri-loader';
import esri = __esri;
import { GeographicData } from '../entities/geographic-data';
import { LossDataDashboardService } from '../loss-data-dashboard.service';
import * as _ from 'lodash';
import { Action } from 'rxjs/scheduler/Action';
import * as html2canvas from 'html2canvas';
import { Attribute } from '@angular/compiler';
import canvg from 'canvg-browser';


@Component({
    selector: 'losses-by-location',
    templateUrl: './losses-by-location.component.html',
    styleUrls: ['./losses-by-location.component.css']
})

export class LossesByLocationComponent implements OnInit {

    geographicData: GeographicData[];

    @Output() mapLoaded = new EventEmitter<boolean>();

    @ViewChild('mapViewNode') private mapViewEl: ElementRef;


    constructor(private lossDataDashboardService: LossDataDashboardService) {
    }

    ngOnInit() {
        this.getLossesByLocation();
    }

    private getLossesByLocation() {

        this.lossDataDashboardService.getLossesByLocation()
            .subscribe((response) => {
                this.geographicData = response;
                this.loadMap();
            });
    }

    private loadMap() {

        loadModules([
            'esri/Map',
            'esri/views/MapView',
            "esri/geometry/Point",
            "esri/symbols/SimpleMarkerSymbol",
            "esri/Graphic",
            "esri/widgets/Popup",
            "esri/widgets/Attribution",
            "dojo/_base/array",
            "dojo/dom-style",
            "esri/widgets/Print",
            "esri/WebMap",
            "esri/widgets/Legend",
            "esri/widgets/Expand",
            "dojo/dom",
            "dijit/form/Button",
            "dojo/domReady!"
        ])
            .then(([EsriMap,
                EsriMapView,
                EsriPoint,
                SimpleMarkerSymbol,
                Graphic,
                Popup,
                Attribution,
                arrayUtils,
                domStyle, Print, WebMap, Legend, Expand, dom, Button]) => {

                const mapProperties: esri.MapProperties = {
                    basemap: "osm"
                };

                let map: esri.Map = new EsriMap(mapProperties);

                const mapViewProperties: esri.MapViewProperties = {
                    container: this.mapViewEl.nativeElement,
                    map: map,
                    zoom: 2,
                    constraints: {
                        maxZoom: 2
                    },
                    popup: {
                        autoCloseEnabled: true,
                        dockOptions: {
                            buttonEnabled: false
                        },


                    }
                };

                let mapView: esri.MapView = new EsriMapView(mapViewProperties);
                let list: any[] = [];
                let size: number = 2;

                function mapLoaded(geographicData) {

                    arrayUtils.forEach(geographicData, function (point: GeographicData) {

                        let item = _.find(list, (e) => { return e.value == point.value });
                        if (item == null) {
                            size = size + 0.5;
                            item = { value: point.value, size: `${size}px` };
                            list.push(item);
                        }
                        var graphic = new Graphic({
                            geometry: new EsriPoint([point.longitude, point.latitude]),
                            symbol: createSymbol(item.size),
                            attributes: {
                                "Total Actual Losses": point.value,
                                "Location": point.location
                            },

                            popupTemplate: {
                                title: "",
                                content: [{
                                    type: "fields",
                                    fieldInfos: [
                                        {
                                            fieldName: "Total Actual Losses"
                                        },
                                        {
                                            fieldName: "Location"
                                        }
                                    ]
                                }]
                            }

                        });

                        mapView.graphics.add(graphic);

                    });
                }

                function createSymbol(size) {

                    let symbol: any = {
                        type: "simple-marker",
                        style: "circle",
                        color: "black",
                        size: size,
                        outline: {
                            color: [255, 255, 255]
                        }
                    };

                    return symbol;
                }

                mapView.when(() => {

                    mapLoaded(this.geographicData);

                    mapView.ui.remove(["attribution"]);

                    // attribution:{
                    //     Text:"test";
                    // }
                    // mapView.ui.add(["attribution"]);
                    // //const attribution: esri.Attribution= new Attribution({
                    // attribution: {
                    //     attributionText: "Test"

                    // }
                    // });
                    // const legend: esri.Expand = new Expand({
                    //     content: print,
                    //     autoCollapse: true,
                    //     view: mapView,
                    //     expanded: false
                });
                //mapView.ui.add(legend, "bottom-left");

                // var print: esri.Print = new Print({
                //     view: mapView,
                //     printServiceUrl: "https://utility.arcgisonline.com/arcgis/rest/services/Utilities/PrintingTools/GPServer/Export%20Web%20Map%20Task"
                // });

                //print.startup();

                //mapView.ui.add(print, "bottom-left");
                // this.disableZooming(mapView);
                this.mapLoaded.emit(true);
            }, err => {
                console.error(err);
            });
        //})
        // .catch(err => {
        //     console.error(err);
        // });
    }


    onExport() {
        var date = new Date();
        var monthArray = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        var month = monthArray[date.getMonth()];
        html2canvas(document.getElementById('map')).then(function (canvas) {
            var ctx = canvas.getContext("2d");
            var filename = "Total losses By location_" + date.getDate() + '_' + month + '_' + date.getFullYear() + '_' + date.getHours() + '_' + date.getMinutes();
            if (canvas.msToBlob) { //for IE
                var blob = canvas.msToBlob();
                window.navigator.msSaveBlob(blob, filename + '.jpg');
            }
            else {
                var a = document.createElement('a');
                a.href = canvas.toDataURL("image/jpeg").replace("image/jpeg", "image/octet-stream");
                a.download = filename + '.jpg';
            }
            a.click();
        });
    }
    exportGraph() {
        var date = new Date();
        var monthArray = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        var month = monthArray[date.getMonth()];
        var transform = $(".esri-display-object").css("transform");
        if (transform) {
            var c = transform.split(",");
            var d = parseFloat(c[4]);
            var h = parseFloat(c[5]);
            $(".esri-display-object").css({
                "transform": "none",
                "left": d,
                "top": h
            })
        }
        html2canvas(document.getElementById('map'),
            {
                useCORS: true,
                allowTaint: false,
                logging: true
            }).then(function (canvas) {
                var ctx = canvas.getContext("2d");
                var filename = "Total losses By location_" + date.getDate() + '_' + month + '_' + date.getFullYear() + '_' + date.getHours() + '_' + date.getMinutes();
                if (canvas.msToBlob) { //for IE
                    var blob = canvas.msToBlob();
                    window.navigator.msSaveBlob(blob, filename + '.jpg');
                }
                else {
                    var a = document.createElement('a');
                    a.href = canvas.toDataURL("image/jpeg").replace("image/jpeg", "image/octet-stream");
                    a.download = filename + '.jpg';
                    a.click();
                }

                $(".esri-display-object").css({
                    left: 0,
                    top: 0,
                    "transform": transform
                })
            });
    }
    // exportGraph4() {
    //     var date = new Date();
    //     var monthArray = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    //     var month = monthArray[date.getMonth()];
    //     html2canvas(document.getElementById('ng'),
    //         {
    //             useCORS: true, 
    //             allowTaint: true,
    //             logging: true
    //         }).then(function (canvas) {
    //             var ctx = canvas.getContext("2d");
    //             var filename = "Total losses By location_" + date.getDate() + '_' + month + '_' + date.getFullYear() + '_' + date.getHours() + '_' + date.getMinutes();
    //             if (canvas.msToBlob) { //for IE
    //                 var blob = canvas.msToBlob();
    //                 window.navigator.msSaveBlob(blob, filename + '.jpg');
    //             }
    //             else {
    //                 var a = document.createElement('a');
    //                 a.href = canvas.toDataURL("image/jpeg").replace("image/jpeg", "image/octet-stream");
    //                 a.download = filename + '.jpg';
    //                 a.click();
    //             }
    //         });
    // }
    // exportGraph3() {
    //     var date = new Date();
    //     var monthArray = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    //     var month = monthArray[date.getMonth()];
    //     let nodeList = document.getElementById('map');
    //     let divNodes: any = nodeList.childNodes[0].firstChild;
    //     html2canvas($(nodeList.childNodes[1].firstChild).find('.esri-display-object')[0],
    //         {
    //             useCORS: true, 
    //             allowTaint: true,
    //             logging: true
    //         }).then(function (canvas) {
    //             var ctx = canvas.getContext("2d");
    //             var filename = "Total losses By location_" + date.getDate() + '_' + month + '_' + date.getFullYear() + '_' + date.getHours() + '_' + date.getMinutes();
    //             if (canvas.msToBlob) { //for IE
    //                 var blob = canvas.msToBlob();
    //                 window.navigator.msSaveBlob(blob, filename + '.jpg');
    //             }
    //             else {
    //                 var a = document.createElement('a');
    //                 a.href = canvas.toDataURL("image/jpeg").replace("image/jpeg", "image/octet-stream");
    //                 a.download = filename + '.jpg';
    //                 a.click();
    //             }
    //         });
    // }
}


