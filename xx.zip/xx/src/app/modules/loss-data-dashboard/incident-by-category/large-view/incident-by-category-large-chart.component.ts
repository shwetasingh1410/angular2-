import { Component, OnInit, ViewChild, ElementRef } from "@angular/core";
import { SearchField } from "../../../search/entities/search-field";
import { ChartFilter, GraphLegends } from "../../entities/chart-filter";
import { LossDataDashboardService } from "../../loss-data-dashboard.service";
import { ChartLookup } from "../../entities/chart-lookup";
import { ChartData } from "../../../../user-controls/chart/entities/chart-data";
import * as _ from 'lodash';
import * as html2canvas from 'html2canvas';
import canvg from 'canvg-browser';

@Component({
    selector: 'incident-by-category-large-chart',
    templateUrl: './incident-by-category-large-chart.component.html',
    styleUrls: ['./incident-by-category-large-chart.component.css']
})

export class IncidentByCategoryLargeChartComponent implements OnInit {

    chartFilter: ChartFilter = new ChartFilter();

    chartLookup: ChartLookup = new ChartLookup();

    chartData: ChartData;

    selectedItems: any[];

    removalCountCategory1: number = 0;

    removalCountCategory2: number = 0;

    constructor(private lossDataDashboardService: LossDataDashboardService) {
    }

    ngOnInit() {
        this.getLossDataFilters();
        document.getElementById('radio3').click();
        document.getElementById('radio33').click();
    }

    onUpDownPowerChange() {
        this.getIncidentByCategory();
    }


    onItemSelect(item: any) {

        if (this.chartFilter.legend == GraphLegends.Category1) {

            this.removalCountCategory2 = 0;

            this.removalCountCategory1 = this.removalCountCategory1 - 1;

            this.chartFilter.category2 = null;

            this.chartFilter.category1 = this.chartFilter.category1 || [];

            this.chartFilter.category1.push(item.id);

        } else {
            this.removalCountCategory1 = 0;

            this.removalCountCategory2 = this.removalCountCategory2 - 1;

            this.chartFilter.category1 = null;

            this.chartFilter.category2 = this.chartFilter.category2 || [];

            this.chartFilter.category2.push(item.id);
        }

        if (item.reload) {
            this.getIncidentByCategory();
        }
    }

    onItemRemove(item: any) {

        if (this.chartFilter.legend == GraphLegends.Category1) {

            this.removalCountCategory2 = 0;
            this.removalCountCategory1 = this.removalCountCategory1 + 1;
            this.chartFilter.category2 = null;
            if (this.removalCountCategory1 == (0 - this.chartLookup.category1.length)) {
                this.chartFilter.category1 = [5000000];
            }
            this.chartFilter.category1 = _.filter(this.chartFilter.category1, (e: number) => { return e != item.id });


        } else {

            this.removalCountCategory1 = 0;
            this.removalCountCategory2 = this.removalCountCategory2 + 1;
            this.chartFilter.category1 = null;
            if (this.removalCountCategory2 == (0 - this.chartLookup.category2.length)) {
                this.chartFilter.category2 = [5000000];
            }
            this.chartFilter.category2 = _.filter(this.chartFilter.category2, (e: number) => { return e != item.id });
        }
        if (item.reload) {
            this.getIncidentByCategory();
        }

    }

    private getLossDataFilters() {

        this.lossDataDashboardService.getIncidentByCategoryFilters()
            .subscribe(response => {

                this.chartLookup = response;
                this.chartLookup.category1.splice(0, 0, new SearchField(null, "All"));
                this.chartLookup.category2.splice(0, 0, new SearchField(null, "All"));

                this.selectedItems = [new SearchField(null, "All")];
                this.chartFilter.upDownPowerStreamId.push(this.chartLookup.upDownPowerStream[2].id);
                this.chartFilter.category1 = null;
                this.chartFilter.category2 = null;
                this.chartFilter.legend = GraphLegends.Category1;
            });
    }

    categoryChange(option) {
        this.chartFilter.legend = option;

    }
    private getIncidentByCategory() {

        this.lossDataDashboardService.getIncidentByCategory(this.chartFilter)
            .subscribe((response) => {
                if (response) {
                    _.each(response, (item) => {
                        item.sliced = true;
                    });
                    this.chartData = response;
                }
            });
    }

    exportGraph() {
        var date = new Date();
        var monthArray = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        var month = monthArray[date.getMonth()];
        let nodeList: NodeList = document.getElementsByTagName('pie-chart1');
        let divNodes: any = nodeList[1].childNodes[0].firstChild;
        let svg: any = $(divNodes).find('.highcharts-root')[0];
        var canvas = document.createElement('canvas');
        canvg(canvas, divNodes.innerHTML);
        var filename = "Incidents view by Main Categories_" + date.getDate() + '_' + month + '_' + date.getFullYear() + '_' + date.getHours() + '_' + date.getMinutes();
        if (canvas.msToBlob) { //for IE
            var blob = canvas.msToBlob();
            window.navigator.msSaveBlob(blob, filename + '.jpg');
        }
        else {
            var a = document.createElement('a');
            a.href = canvas.toDataURL("image/jpeg").replace("image/jpeg", "image/octet-stream");
            a.download = filename + '.jpg';
            a.click();
        }
    }

}
