import { Component, OnInit, ViewChild, ElementRef, AfterViewInit } from "@angular/core";
import { Chart } from 'highcharts';
import { LossDataDashboardService } from "../../loss-data-dashboard.service";
import { ChartFilter, GraphLegends } from "../../entities/chart-filter";
import { ChartData } from "../../../../user-controls/chart/entities/chart-data";
import * as _ from 'lodash';

@Component({
    selector: 'incident-by-category-small-chart',
    templateUrl: './incident-by-category-small-chart.component.html',
    styleUrls: ['./incident-by-category-small-chart.component.css']
})

export class IncidentByCategorySmallChartComponent implements OnInit {

    chartData: any;

    constructor(private lossDataDashboardService: LossDataDashboardService) {
    }

    ngOnInit() {
        this.getIncidentByCategory();
    }

    onExpand() {
        document.getElementById("incidentByCategoryBtn").click();
    }

    private getIncidentByCategory() {

        let chartFilter = new ChartFilter();        
        chartFilter.category1 = null;
        chartFilter.category2 = null;
        chartFilter.upDownPowerStreamId = null;
        chartFilter.legend = GraphLegends.Category1;

        this.lossDataDashboardService.getIncidentByCategory(chartFilter)
            .subscribe((response) => {
                if (response) {
                    _.each(response, (item) => {
                        item.sliced = true;
                    });
                    this.chartData = response;
                }
            });
    }
}