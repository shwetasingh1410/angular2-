import { Component, OnInit } from "@angular/core";
import { ChartFilter, GraphLegends } from "../../entities/chart-filter";
import { LossDataDashboardService } from "../../loss-data-dashboard.service";
import { ChartLookup } from "../../entities/chart-lookup";
import { ChartData } from "../../../../user-controls/chart/entities/chart-data";
import * as _ from 'lodash';
import { SearchField } from "../../../search/entities/search-field";
import * as html2canvas from 'html2canvas';
import canvg from 'canvg-browser';
@Component({
    selector: 'incident-by-loss-type-large-chart',
    templateUrl: './incident-by-loss-type-large-chart.component.html',
    styleUrls: ['./incident-by-loss-type-large-chart.component.css']
})

export class IncidentByLossTypeLargeChartComponent implements OnInit {

    chartFilter: ChartFilter = new ChartFilter();

    chartLookup: ChartLookup = new ChartLookup();

    chartData: ChartData;

    selectedItems: any[];

    columnColor: any[] = [];

    removalCountUD: number = 0;

    removalCountArea: number = 0;

    constructor(private lossDataDashboardService: LossDataDashboardService) {
    }

    ngOnInit() {
        this.getLossDataFilters();
    }

    onYearChange() {
        this.getMajorLossesByYear();
    }

    onLossValueChange() {
        this.getMajorLossesByYear();
    }

    compareFn(obj1: any, obj2: any): boolean {
        return obj1 && obj2 ? obj1.id === obj2.id : obj1 === obj2;
    }

    onUpDownItemSelect(item: any) {
        this.removalCountUD=this.removalCountUD-1;
        this.chartFilter.upDownPowerStreamId = this.chartFilter.upDownPowerStreamId || [];
        this.chartFilter.upDownPowerStreamId.push(item.id);
        if (item.reload) {
            this.getMajorLossesByYear();
        }
    }

    onAreaItemSelect(item: any) {
        this.removalCountArea=this.removalCountArea-1;
        this.chartFilter.areaId = this.chartFilter.areaId || [];
        this.chartFilter.areaId.push(item.id);
        if (item.reload) {
            this.getMajorLossesByYear();
        }
    }

    onUpDownItemRemove(item: any) {
        this.removalCountUD=this.removalCountUD+2;
        this.chartFilter.upDownPowerStreamId = _.filter(this.chartFilter.upDownPowerStreamId, (e: number) => { return e != item.id });
        if(this.removalCountUD==0)
        {
            this.chartFilter.upDownPowerStreamId=[5000000];
        }
        if (item.reload) {
            this.getMajorLossesByYear();
        }
    }

    onAreaItemRemove(item: any) {
        this.removalCountArea=this.removalCountArea+2;
        this.chartFilter.areaId = _.filter(this.chartFilter.areaId, (e: number) => { return e != item.id });
        if(this.removalCountArea==0)
        {
            this.chartFilter.areaId=[5000000];
        }
        if (item.reload) {
            this.getMajorLossesByYear();
        }
    }

    private getLossDataFilters() {

        this.lossDataDashboardService.getMajorLossesByYearFilters()
            .subscribe(response => {

                this.chartLookup = response;
                this.chartLookup.upDownPowerStream.splice(0, 0, new SearchField(null, "All"));
                this.chartLookup.areas.splice(0, 0, new SearchField(null, "All"));
                this.chartLookup.majorIncidentLossValue = [];
                this.chartLookup.majorIncidentLossValue.push("100M+");
                this.chartLookup.majorIncidentLossValue.push("250M+");
                this.chartLookup.majorIncidentLossValue.push("500M+");
                this.setDefaultFilters();
            });
    }

    private setDefaultFilters() {

        this.selectedItems = [new SearchField(null, "All")];

        this.chartFilter.majorIncidentLossValue = "100M+";

        const currentYear = new Date().getFullYear().toString();

        if (this.chartLookup.yearOfLoss.indexOf(currentYear) > -1) {
            this.chartFilter.toYear = currentYear;
        } else {
            this.chartFilter.toYear = _.last(this.chartLookup.yearOfLoss);
        }

        this.chartFilter.fromYear = (parseInt(this.chartFilter.toYear) - 10).toString();
    }

    private getMajorLossesByYear() {

        if (this.validateYearRange()) {
        this.lossDataDashboardService.getMajorLossesByYear(this.chartFilter)
            .subscribe((response) => {
                this.chartData = response;
                this.columnColor = ['#FDB71E'];
                this.chartData.xAxisTitle = "Years";
                this.chartData.yAxisTitle = "Total Claims in US$";
            });
        }
    }

    private validateYearRange() {

        if (parseInt(this.chartFilter.toYear) - parseInt(this.chartFilter.fromYear) > 15) {
            alert("You can select up to max 15 years of range at a time.");
            return false;
        }

        return true;
    }

    exportGraph() {
        var date = new Date();
        var monthArray = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        var month = monthArray[date.getMonth()];
        let nodeList: NodeList = document.getElementsByTagName('stacked-column-chart');
        let divNodes: any = nodeList[7].childNodes[0].firstChild;
        let svg: any = $(divNodes).find('.highcharts-root')[0];
        var canvas = document.createElement('canvas');
        canvg(canvas, divNodes.innerHTML);
        var filename = "Major Losses by Year_" + date.getDate() + '_' + month + '_' + date.getFullYear() + '_' + date.getHours() + '_' + date.getMinutes();
            if (canvas.msToBlob) { //for IE
            var blob = canvas.msToBlob();
            window.navigator.msSaveBlob(blob, filename + '.jpg');
        }
        else {
            var a = document.createElement('a');
            a.href = canvas.toDataURL("image/jpeg").replace("image/jpeg", "image/octet-stream");
            a.download = filename + '.jpg';
            a.click();
        }
    }
}
