export class GeographicData {
    latitude: number;
    longitude: number;
    value: number;
    location:string;
}