import { Component, OnInit,EventEmitter,Output } from '@angular/core';
import { ConfirmationModal } from  './entities/confirmation-modal';
import { NotificationMessage } from '../common/entity/notification-message';


@Component({
    selector: 'eldm-param-value',
    templateUrl: './eldm-param-value.component.html',
    styleUrls: ['./eldm-param-value.component.css']
  })

export class EldmParamValueComponent implements OnInit{
    confirmationModal: ConfirmationModal = new ConfirmationModal();
    notificationMessage:NotificationMessage =new NotificationMessage();
 valueName:string;
 editValue:string="";
 categoryName:string="";
 editSubValue:string=""
range:string=""
 i1:number;
 list=[];
 subList=[];
 isUpdate:boolean=false;
 isUpdateCostCategory:boolean=false;
 isCostCategory:boolean=false;
 isSplitted:boolean=false;
 isOther:boolean=false;
 isUpstream:boolean=false;
 isDownstream:boolean=false;
 isPower:boolean=false;
 selectedUs:boolean=false;
 selectedP:boolean=false
 selectedDs:boolean=false;
 @Output() onAddEvent = new EventEmitter();

areas=['Africa','Australia','Caribbean','Europe','Eastern Europe','Far East']
countries=['Albania','Algeria','Aruba','Australia','Argentina'];
costCat=[{'category':'A','range':'100-200'},{'category':'B','range':'100-200'},{'category':'C','range':'100-200'},{'category':'D','range':'100-200'}]
category1=["Chemical","Gas plant","MOPU","Oil sands","Petrochemical","Pipeline","Plant","Platform","Power Nuclear","Power Other ","Power Renewable","Power Substation","Power T&D","Power Thermal","Refinery","Renewables","Rig","SBMetc.","SSCS","Tank farm/terminal","Vessel","Well"]
parameters=["Adjuster","Adjuster Individual","Area","Asset","Assured","Category 1","Category 2","Category 3","Cause","Cost Category","Country","Depth Category","Drilling Status","Equipment Type","Event","Field/Unit","GOM Area","Generation","Land/Offshore","Loss Type","Model","Model OEM Country Manufacture","Operational Status","Platform","Product","Rating Area","Shale Formation","Source","US Location Codes","Up/Down/Power","WELL Type"];
lossTypes=["BI","CBI","LIAB","OEE","PD","S&P"];
udp=["Upstream","Downstream","Power"];
valuesup=["value 1" ,"value 2" ,"value 3","value 4","value 5"];
valuesdown=["value 1" ,"value 2" ,"value 3","value 4","value 5"];
valuespower=["value 1" ,"value 2" ,"value 3","value 4","value 5"];

    constructor(){}

    ngOnInit(){
this.list=[];
this.subList=[];
    }

    onEdit(item){
        this.isUpdate=true
        this.editValue=item;
          this.i1=this.list.indexOf(item);


    }
    onEditSub(item){
        this.isUpdate=true
        this.editSubValue=item;
          this.i1=this.subList.indexOf(item);


    }
   
    onEditCostCategory(category,range){
        this.isUpdateCostCategory=true
        this.categoryName=category;
        this.range=range;
         this.i1=this.list.findIndex(x=>x.category==this.categoryName)
         console.log(this.i1)
        //   this.notificationMessage.successMessage="Value has been updated successfully!"


    }

    onUpdate(updatedVal,i){
        //push the value in place i;
        //this.list.splice(i,i,updatedVal);
        // console.log(updatedVal);
        this.isUpdate=false
                 this.notificationMessage.successMessage="Value has been updated successfully!"

    }

    onUpdateCostCategory(category,range){
        //push the value in place i;
        //this.list.splice(i,i,updatedVal);
        // console.log(updatedVal);
        this.isUpdateCostCategory=false
                 this.notificationMessage.successMessage="Value has been updated successfully!"

    }



    onAdd(newVal){
        this.list.push(newVal);
        this.notificationMessage.successMessage="Value has been added successfully!"

    }
    onAddSub(newVal){
        this.subList.push(newVal);
        this.notificationMessage.successMessage="Value has been added successfully!"
    }

    onAddCostCategory(categoryName,range){
        this.list.push({"category":categoryName,"range":range});
        this.notificationMessage.successMessage="Value has been added successfully!"

    }


    cancel(){
        this.isUpdate=false;
        this.isUpdateCostCategory=false;

    }
    cancelCostCat(){
        this.isUpdateCostCategory=false;

    }
    onSubSelect(val){
        this.isUpdate=false;

           switch(val){
               case "Upstream":{
                   this.subList=this.valuesup;
                this.isUpstream=true;
                this.isDownstream=false;
                this.isPower=false;
                this.selectedUs=true;
                this.selectedDs=false;
                this.selectedP=false;
                break;
               }
               case "Downstream":{
                this.subList=this.valuesdown;
             this.isDownstream=true;
             this.isUpstream=false;
             this.isPower=false;
             this.selectedUs=false;
             this.selectedP=false;
             this.selectedDs=true;


             break;
            }
            case "Power":{
                this.subList=this.valuespower;
             this.isPower=true;
             this.isUpstream=false;
             this.isDownstream=false;
             this.selectedP=true;
             this.selectedUs=false;
             this.selectedDs=false;
             break;
            }
            default:{
                this.subList=[];
            }
           }

    }

   
    onSelect(val){
        this.valueName=val;
        this.isUpstream=false;
        this.isDownstream=false;
        this.isPower=false;
        if(val=='Cost Category' || val=="Category 1"){
            switch(val){
                case "Cost Category":{
                    this.list=this.costCat;
                    this.isCostCategory=true;
                    this.isSplitted=false;

                     break;
                 };
                 case "Category 1":{
                    this.list=this.udp;
                    this.isSplitted=true;
                    this.isCostCategory=false;

                     break;
                 };
                 default:{
                    this.list=[];
                }
            }
        }

        else{
            this.isCostCategory=false;
            this.isSplitted=false;
            switch(val){
                case "Area":{
                   this.list=this.areas;
                    break;
                };
                case "Country":{
                   this.list=this.countries;
              
                    break;
                };
             
                 case "Loss Type":{
                    this.list=this.lossTypes;
                     break;
                 };
                 case "Up/Down/Power":{
                    this.list=this.udp;
                     break;
                 };
             default:{
                 this.list=[];
             }
    
              
                }
          
        }
    }
}