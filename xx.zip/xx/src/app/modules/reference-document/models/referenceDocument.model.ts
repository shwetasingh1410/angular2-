import { Observable } from 'rxjs/Rx';
import { ReferenceDocumentService } from '../services/reference-document.service';
import { ReferenceDocument } from '../entities/reference-document';

export class ReferenceDocumentModel {

    constructor(private referenceDocumentService: ReferenceDocumentService){

    }

    getAllDocuments(): Observable<ReferenceDocument[]> {
        return this.referenceDocumentService.getAllDocuments();
   }

   addDocument(document:ReferenceDocument):Observable<ReferenceDocument>
   {
       return this.referenceDocumentService.addDocument(document)
   }

   updateDocument(document:ReferenceDocument):Observable<boolean>
   {
       return this.referenceDocumentService.updateDocument(document);
   }

   deleteDocument(id:string):Observable<boolean>{
       return this.referenceDocumentService.deleteDocument(id);
   }

   getDocumentContent(filename:string): Observable<ReferenceDocument> {
    return this.referenceDocumentService.getDocumentContent(filename);
}

   

}

