export class ReferenceDocument
{
    filename :string;
    contentType :string;
    content:number[];
    CreatedOn:string;
    title:string;

}