import { SelectedSearchCriteria } from "./search-criteria";
export class SearchSaveCriteria
{
    id : string;
    TemplateName :string;
    SearchCriteria: SelectedSearchCriteria;

}