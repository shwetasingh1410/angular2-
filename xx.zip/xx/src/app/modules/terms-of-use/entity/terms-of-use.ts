export class TermsOfUse{
    id:number;
    version:number; 
    termsOfUseText:string;
    publishedBy:string;
    publishedOn:string;

}