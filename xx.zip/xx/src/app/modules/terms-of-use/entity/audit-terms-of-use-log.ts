export class AuditTermsOfUseLog{

    version:number; 
    action:string;
   
}