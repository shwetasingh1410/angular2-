export class AcceptedTermsOfUse
{
    principalId:number;
    userId:string;
    version:number;
}