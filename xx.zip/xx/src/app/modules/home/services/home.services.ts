

import { HttpClientWrapper } from '../../../shared/http/http-client-wrapper';
import { Observable } from 'rxjs/Rx';
import { Injectable } from '@angular/core';
import { WebRequestParameter } from '../../../shared/http/web-request-parameter';
import { Announcement } from '../entity/announcement';
import { Document } from '../entity/document';

@Injectable()
export class HomeService {

    constructor(private httpClientWrapper: HttpClientWrapper) {
    }

    getAnnouncements(): Observable<Announcement[]> {
      let webRequestParams = new WebRequestParameter("announcements");      
      return this.httpClientWrapper.get<Announcement[]>(webRequestParams);
    }
    getDocuments(): Observable<Document[]> {
      let webRequestParams = new WebRequestParameter("documents");      
      return this.httpClientWrapper.get<Document[]>(webRequestParams);
    }
    getDocumentContent(filename:string): Observable<Document> {
      let webRequestParams = new WebRequestParameter("documents/"+filename);      
      return this.httpClientWrapper.get<Document>(webRequestParams);
    }
}












