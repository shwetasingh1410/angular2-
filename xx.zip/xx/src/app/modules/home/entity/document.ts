export class Document {    
    filename: string;
    contentType: string;    
    content: string;
    metadata: string;
    title:string;
   }