export class KeyValuePair {

    key: string;
    value: any;

    constructor(_key: string, _value: any) {
        this.key = _key;
        this.value = _value;
    }
}