export class SearchParams {
    searchText: string;
}