export class ConfirmationModal{ 
    
    headerMessage:string;
    bodyMessage:string;

}