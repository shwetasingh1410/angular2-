export class TermsOfUse{
    id:string;
    termsOfUseText:string;
    version:number;
    publishedOn:string;
}