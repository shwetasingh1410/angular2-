export class UserSearchParams {
    searchText: string;
    roleId: number;
    userType: string;
}