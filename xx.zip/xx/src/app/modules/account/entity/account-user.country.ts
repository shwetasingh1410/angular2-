export class AccountUserCountry{        
    id:string;    
    name:string;        
}