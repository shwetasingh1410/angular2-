export class AccountUserInfo{        
    firstName:string;    
    lastName:string;
    company: string;
    countryName: string;        
}
