export class AccountUserCity{        
    id:number;    
    name:string;
    code:string;        
}