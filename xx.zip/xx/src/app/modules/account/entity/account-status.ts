export class AccountStatus {
    active: number;
    inactive: number;
}