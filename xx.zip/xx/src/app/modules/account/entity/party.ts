export class Party {
    partyId: string;
    name: string;
}