export class AccountNotifications {
    clientName: string;
    expiryDate: Date;
    keyContact:string;
    email: string;
    sentDate: string;
}