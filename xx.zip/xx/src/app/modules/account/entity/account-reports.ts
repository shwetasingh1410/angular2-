export class AccountReports {
    filename: string;
    contentType: string;
    content: any[];
    title: string;
    createdDate: Date;
}