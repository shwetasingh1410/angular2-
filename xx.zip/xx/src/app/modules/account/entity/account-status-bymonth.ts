export class AccountStatusByMonth {
    month: string;
    count: number;
}