export class ActivityLogSearch {

    userName: string;
    action: string;
    fromDate: string;
    toDate: string;
    serverIp: string;
    searchCriteria: string;
    viewModule: string;
    
}