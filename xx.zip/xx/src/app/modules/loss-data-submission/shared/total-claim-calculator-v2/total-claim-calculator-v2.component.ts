import { Component, OnInit , Input, Output , EventEmitter, OnChanges , SimpleChanges } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'total-claim-calculator-v2',
  templateUrl: './total-claim-calculator-v2.component.html',
  styleUrls: ['./total-claim-calculator-v2.component.css']
})
export class TotalClaimCalculatorV2Component implements OnInit,OnChanges {
  pd: number = 0;
//   oee: number = 0;
  bi: number = 0;
  total: number = 0;
  valChange:boolean;
  @Input() resetFlag:boolean;
  @Input() readonlyFlag:boolean;
  @Input() pdLoss:number;
  @Input() biLoss:number;
  @Output() pdVal:EventEmitter<number>=new EventEmitter();
  @Output() biVal:EventEmitter<number>=new EventEmitter();
  @Output() inValidFlag:EventEmitter<boolean>= new EventEmitter<boolean>();

  constructor() {
  }

  ConvertToInt(val) {
    return parseInt(val);
  }

  ngOnInit() {
  }

  ngOnChanges(changes: SimpleChanges)
  {
    if(changes['resetFlag'] !== undefined)
    {
      this.pd=0;
      this.bi=0;
      this.valChange=false;
    }
    if(this.readonlyFlag)
    {
      
      this.total=this.pdLoss+this.biLoss;

    }
  }
  onChange() {
   
  this.total = this.ConvertToInt(this.pd) + this.ConvertToInt(this.bi) ;
  this.pdVal.emit(this.pd);
  this.biVal.emit(this.bi);
  this.valChange=true;
  if(this.total<=0)
      this.inValidFlag.emit(true);
      else
      this.inValidFlag.emit(false);
      // this.total = this.pd + this.bi + this.oee;
  }

  formatInput(input) {
    if (input && input.length > 0) {
      input = input.replace(/^0+/, '');
      if (input.length == 0) {
        return input = '0';
      } else {
        return input;
      }
    } else return input;

  }

}
