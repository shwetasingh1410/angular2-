import { Component, OnChanges, OnInit,SimpleChanges, Input, Output ,EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
 

@Component({
  selector: 'total-claim-calculator',
  templateUrl: './total-claim-calculator.component.html',
  styleUrls: ['./total-claim-calculator.component.css']
})
export class TotalClaimCalculatorComponent implements OnInit ,OnChanges {
  pd: number = 0;
  oee: number = 0;
  bi: number = 0;
  total: number = 0;
  valChange:boolean;
  @Input() resetVal:boolean;
  @Input() readonlyFlag:boolean;
  @Input() pdLoss:number;
  @Input() biLoss:number;
  @Input() oeeLoss:number;
  @Output() pdVal: EventEmitter<any> = new EventEmitter<any>();
  @Output() biVal: EventEmitter<any> = new EventEmitter<any>();
  @Output() oeeVal: EventEmitter<any> = new EventEmitter<any>();
  @Output() inValidFlag:EventEmitter<boolean>= new EventEmitter<boolean>();
  constructor() {
  }
  ConvertToInt(val) {
    return parseInt(val);
  }

  ngOnInit() {
  }

  ngOnChanges(changes: SimpleChanges) {
    if(changes['resetFlag'] !== undefined)
    {
      this.pd=0;
      this.oee=0;
      this.bi=0;
      this.total=0;
      this.valChange=false;
    }
  
      if(this.readonlyFlag)
    {
      
      this.total=this.pdLoss+this.biLoss+this.oeeLoss;

    }
  }


  onChange() {
  this.total = this.ConvertToInt(this.pd) + this.ConvertToInt(this.bi) + this.ConvertToInt(this.oee);
      // this.total = this.pd + this.bi + this.oee;
      this.pdVal.emit(this.pd);
      this.oeeVal.emit(this.oee);
      this.biVal.emit(this.bi);
      this.valChange=true;
      if(this.total<=0)
      this.inValidFlag.emit(true);
      else
      this.inValidFlag.emit(false);
  }

  formatInput(input) {
    if (input && input.length > 0) {
      input = input.replace(/^0+/, '');
      if (input.length == 0) {
        return input = '0';
      } else {
        return input;
      }
    } else return input;

  }

}
