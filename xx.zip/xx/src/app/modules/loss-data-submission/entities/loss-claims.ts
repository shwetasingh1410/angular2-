export class LossClaims
{
lossClaimID:number;
lossID:number;
coverageTypeId:number;
lossAmount:number;
closeFlag: boolean;
incomplete: boolean;
status:string;
statusComment:string;
}