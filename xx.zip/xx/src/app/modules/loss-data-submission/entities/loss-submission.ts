export class LossSubmission
{
    submissionId:number;
    adjusterFileRef:string;
    clientName :string ;
    lossType :string;
    submittedBy :string;
    submissionDate :string;
    status : string;
    statusComment : string;
    reviewDate :string;
    incidentId : number;

}