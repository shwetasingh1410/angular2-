export class PartyRole
{
    partyId : number;
    name : string;
    roleId : number;
}