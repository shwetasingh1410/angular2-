export class LocationDetails
{
    locationId:number;
    areaId:number;
    countryId:number;
    name:string;
    gomAreaID:number;
    locationCodeID:number;
}