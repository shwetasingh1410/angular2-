import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LossDataSubmissionModel } from '../models/loss-data-submission.model';
import { LossDataSubmissionService } from '../services/loss-data-submission.service';
import { LocalWebStorageService } from '../../../shared/storage/local-web-storage.service';
import * as _ from 'lodash';
import { LossData } from '../entities/loss-data';
import { LossSubmission } from '../entities/loss-submission';
@Component({
  selector: 'loss-data-submission-history',
  templateUrl: './loss-data-submission-history.component.html',
  styleUrls: ['./loss-data-submission-history.component.css']
})
export class LossDataSubmissionHistoryComponent implements OnInit {

  constructor(private router: Router, private lossDataSubmissionService: LossDataSubmissionService, private localWebStorageService:LocalWebStorageService )
  {
    this.lossDataSubmissionModel=new LossDataSubmissionModel(lossDataSubmissionService,localWebStorageService)
  }

  selectedLossType: string;
  idFlag: boolean; idFileRef: boolean; idName: boolean; idType: boolean; idSubmittedBy: boolean; idTime: boolean; idStatus: boolean; idStatusComment: boolean;
  lossDataSubmissionModel:LossDataSubmissionModel;
  lossDataSubmissionData:LossSubmission[]=[];
  
  ngOnInit() {
    this.lossDataSubmissionModel.setReadOnlyFlag(false);
    this.getLossDetails();
    
  }

  getLossDetails(){
    this.lossDataSubmissionModel.getAllLossData().subscribe(data=>
      {
       
        this.lossDataSubmissionData=data;
        //console.log(this.lossDataSubmissionData);
      });
  }


  openNewSubmissionModal() {
    document.getElementById('openSelectionModal').click();
  }
  onLossTypeSelection(selectedLossType: string) {
    this.lossDataSubmissionModel.setReadOnlyFlag(false);
    switch (this.selectedLossType) {
      case "UP":
        this.router.navigate(['/loss-data-submission/upstream-loss']);
        break;
      case "DOWN":
        this.router.navigate(['/loss-data-submission/downstream-loss']);
        break;
      case "POWER":
        this.router.navigate(['/loss-data-submission/power-loss']);
        break;
    }
  }
  openReadOnlyMode(selectedLossType: string,id:number) {
    
    this.lossDataSubmissionModel.setReadOnlyFlag(true);
    this.lossDataSubmissionModel.setIncidentId(id);
   
    //console.log(this.lossDataSubmissionModel.getReadOnlyFlag());
    switch (selectedLossType) {
      case "Upstream":
        this.router.navigate(['/loss-data-submission/upstream-loss']);
        break;
      case "Downstream":
        this.router.navigate(['/loss-data-submission/downstream-loss']);
        break;
      case "Power":
        this.router.navigate(['/loss-data-submission/power-loss']);
        break;
    }
  }
  sortById() {
    if (this.idFlag) {
      this.lossDataSubmissionData = _.orderBy(this.lossDataSubmissionData, ['submissionId'], ['asc']);
      this.idFlag = !this.idFlag;
    }
    else {
      this.lossDataSubmissionData = _.orderBy(this.lossDataSubmissionData, ['submissionId'], ['desc']);
      this.idFlag = !this.idFlag;
    }
  }
  sortByFileRef() {
    if (this.idFileRef) {
      this.lossDataSubmissionData = _.orderBy(this.lossDataSubmissionData, ['adjusterFileRef'], ['asc']);
      this.idFileRef = !this.idFileRef;
    }
    else {
      this.lossDataSubmissionData = _.orderBy(this.lossDataSubmissionData, ['adjusterFileRef'], ['desc']);
      this.idFileRef = !this.idFileRef;
    }
  }
  sortByCustomerName() {
    if (this.idName) {
      this.lossDataSubmissionData = _.orderBy(this.lossDataSubmissionData, ['clientName'], ['asc']);
      this.idName = !this.idName;
    }
    else {
      this.lossDataSubmissionData = _.orderBy(this.lossDataSubmissionData, ['clientName'], ['desc']);
      this.idName = !this.idName;
    }
  }
  sortByType() {
    if (this.idType) {
      this.lossDataSubmissionData = _.orderBy(this.lossDataSubmissionData, ['lossType'], ['asc']);
      this.idType = !this.idType;
    }
    else {
      this.lossDataSubmissionData = _.orderBy(this.lossDataSubmissionData, ['lossType'], ['desc']);
      this.idType = !this.idType;
    }
  }
  sortBySubmittedBy() {
    if (this.idSubmittedBy) {
      this.lossDataSubmissionData = _.orderBy(this.lossDataSubmissionData, ['submittedBy'], ['asc']);
      this.idSubmittedBy = !this.idSubmittedBy;
    }
    else {
      this.lossDataSubmissionData = _.orderBy(this.lossDataSubmissionData, ['submittedBy'], ['desc']);
      this.idSubmittedBy = !this.idSubmittedBy;
    }
  }
  sortByTime() {
    if (this.idTime) {
      this.lossDataSubmissionData = _.orderBy(this.lossDataSubmissionData, ['submissionDate'], ['desc']);
      this.idTime = !this.idTime;
    }
    else {
      this.lossDataSubmissionData = _.orderBy(this.lossDataSubmissionData, ['submissionDate'], ['asc']);
      this.idTime = !this.idTime;
    }
  }
  sortByStatus() {
    if (this.idStatus) {
      this.lossDataSubmissionData = _.orderBy(this.lossDataSubmissionData, ['status'], ['asc']);
      this.idStatus = !this.idStatus;
    }
    else {
      this.lossDataSubmissionData = _.orderBy(this.lossDataSubmissionData, ['status'], ['desc']);
      this.idStatus = !this.idStatus;
    }
  }
  sortByStatusComment() {
    if (this.idStatusComment) {
      this.lossDataSubmissionData = _.orderBy(this.lossDataSubmissionData, ['statusComment'], ['asc']);
      this.idStatusComment = !this.idStatusComment;
    }
    else {
      this.lossDataSubmissionData = _.orderBy(this.lossDataSubmissionData, ['statusComment'], ['desc']);
      this.idStatusComment = !this.idStatusComment;
    }
  }
  onClose():void{
  }
}
