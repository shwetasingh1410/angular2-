export class BatchJob
{
    fileName:string;
    contentType:string;
    content:number[];
}