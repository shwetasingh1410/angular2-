export class Announcement {    
    id: string;
    title: string;    
    body: string;
    expiryDate: string;
    fromDate:string;
   }