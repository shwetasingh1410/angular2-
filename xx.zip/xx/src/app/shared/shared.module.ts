import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { DatepickerComponent } from '../user-controls/datepicker/datepicker.component';
import { MultiSelectComponent } from '../user-controls/multi-select/multi-select.component';
@NgModule({
 imports:      [ CommonModule,FormsModule ],
 declarations: [ DatepickerComponent,MultiSelectComponent ],
 exports:      [ DatepickerComponent,MultiSelectComponent ]
})
export class SharedModule { }