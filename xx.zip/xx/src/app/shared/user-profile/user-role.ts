export class UserRole{
    id:number;
    code:string;
    description:string;
}