import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DocAccessComponent } from './doc-access.component';
/*
describe('DocAccessComponent', () => {
  let component: DocAccessComponent;
  let fixture: ComponentFixture<DocAccessComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DocAccessComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocAccessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});*/
