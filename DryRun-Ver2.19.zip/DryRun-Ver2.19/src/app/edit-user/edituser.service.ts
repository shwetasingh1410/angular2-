import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers } from '@angular/http';

import { EditUserHelper } from './edituser.helper';
import { UserDetails, Role, Account, AccountActionIndicator } from './edituser.model';
//import { userSearchResult, roles, accounts } from './edituser.mock.data';

import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';

@Injectable()
export class EditUserService {
    constructor(private _http: Http) {
    }

    getUserSearchResult(searchText: string, userType: number): Observable<Array<UserDetails>> {
        return this._http.get('api/users/' + userType + '/' + searchText)
            .map((response) => {
                //console.log('Get User Search Result');
                //console.log(response.json());
                let result: Array<UserDetails> = new Array<UserDetails>();
                response.json().forEach((user) => {
                    result.push(EditUserHelper.mapToUserDetails(user))
                });
                return result;
            });
    }

    getRoles(): Observable<Array<Role>> {
        return this._http.get('api/users/roles')
            .map((response) => {
                //console.log('Get Roles Result');
                ///console.log(response.json());
                let result: Array<Role> = new Array<Role>();
                response.json().forEach((role) => {
                    result.push(EditUserHelper.mapToRole(role));
                });
                return result;
            });
    }

    getAccounts(): Observable<Array<Account>> {
        return this._http.get('api/accounts/active')
            .map((response) => {
                console.log('Get Account Result');
                console.log(response.json());
                let result: Array<Account> = new Array<Account>();
                response.json().forEach(account => {
                    result.push(EditUserHelper.mapToAccount(account, AccountActionIndicator.Remove));
                });
                return result;
            });
    }

    getUser(userDetails: UserDetails): Observable<UserDetails> {
        console.log('Principal ID ' + userDetails.PrincipleId);
        return this._http.get('api/users/' + userDetails.PrincipleId)
            .map((response) => {
                console.log('Get User Result');
                console.log(response);
                if (response.json() !== null) {
                    let user = response.json();
                    //console.log('ROle Description');
                    //console.log(new Role(user.RoleId, user.RoleCode, user.RoleDescription, user.Rank));
                    userDetails.setUserRole(new Role(user.RoleId, user.RoleCode, user.RoleDescription, user.Rank));
                    //userDetails.setUserRole(user.RoleId);
                    userDetails.setUserId(user.UserId);
                } else {
                    userDetails.setUserRole(new Role('', '', '', 0));
                }
                return userDetails;
            });
    }

    getAccountsForUser(userDetails: UserDetails): Observable<UserDetails> {
        return this._http.get('api/users/' + userDetails.UserId + '/accounts')
            .map((response) => {
                console.log('Get Accounts for User Result');
                console.log(response.json());
                let result: Array<Account> = new Array<Account>();
                response.json().forEach(account => {
                    result.push(EditUserHelper.mapToAccount(account, AccountActionIndicator.None));
                });
                userDetails.AccountList = result;
                return userDetails;
            });
    }

    createUser(userDetails: UserDetails) {
        console.log('Create User');
        console.log(userDetails);
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let options = new RequestOptions({ headers: headers });
        //this._http.post()
        return this._http.post('api/users',
            JSON.stringify({
                'UserPrincipalId': userDetails.PrincipleId,
                'RoleId': userDetails.UserRole.RoleId,
                'Accounts': userDetails.AccountList
            }),options).map((response) => response.json());
    }

    updateUser(userDetails: UserDetails) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let options = new RequestOptions({ headers: headers });
        return this._http.put('api/users/' + userDetails.PrincipleId,
            JSON.stringify({
                    'UserId': userDetails.UserId,
                    'RoleId': userDetails.UserRole.RoleId,
                    'Accounts': userDetails.AccountList
            }),options).map((response) => response.json());
    }
}
