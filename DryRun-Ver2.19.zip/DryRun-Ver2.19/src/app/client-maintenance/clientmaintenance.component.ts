import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import { ClientService } from './clientmaintenance.service';
import { LoggedInUser } from '../shared/loggedInUser/LoggedInUser';
import { PartyInfo, PartyDetails, AssociatedCarrier, Account, ConsultancyStatus, AccountAccess } from './clientmaintenance.model';


@Component({
  selector: 'app-clientmaintenance',
  templateUrl: './clientmaintenance.component.html',
  styleUrls: ['./clientmaintenance.component.css'],
  providers: [ClientService, LoggedInUser]
})


export class ClientMaintenanceComponent implements OnInit {

  value: string;
  searchText: string;
  searchCriteria: string;
  entityStatus: string;
  partyId: number;
  AccountId: number;
  message: string;
  selectedParty: any;
  createButtonLoad = true;
  isModalHidden = false;
  isviewTable = false;
  loadData = false;
  editClient: boolean;
  saveSuccess = false;
  loadAdditonalData = false;
  isError: boolean;
  isSuccess: boolean;
  loggedInuserRank: number;

  clientSearchResult: Array<PartyInfo>;
  clientDropdown: Array<Account>;
  partiesList: Array<PartyDetails>;
  associatedCarriersList: Array<AssociatedCarrier>;
  account: Account;

  constructor(private _router: Router, private _clientService: ClientService, private _loggedInUser: LoggedInUser) {
    
  }


  cancel() {
    this.loadData = false;
    this.searchCriteria = "1";
    this.entityStatus = "1";
    this.searchText = null;
    this.editClient = false;
    this.saveSuccess = false;
    this.loadAdditonalData = false;
    this.isError = false;
    this.isSuccess = false;
    this.isModalHidden = false;
    this.isviewTable = false;
    this.loadData = false;
    this.loadAdditonalData = false;
    this.selectedParty = null;
    //this.account = new Account('', '', 0, '', ConsultancyStatus.NonConsultancy, true, AccountAccess.SuperUsersOnly, []);

    this.account = (this._loggedInUser.UserRole !== undefined && this._loggedInUser.UserRole.Rank === 1) ? new Account('', '', 0, '', ConsultancyStatus.NonConsultancy, true, AccountAccess.SuperUsersOnly, [])
      :
      new Account('', '', 0, '', ConsultancyStatus.NonConsultancy, true, AccountAccess.AllAdmins, []);
  }

  resetSearchModal() {
    this.searchCriteria = "1";
    this.entityStatus = "1";
    this.searchText = null;
    this.saveSuccess = false;
  }

  ngOnInit() {
  }


  loadModal() {
    this.cancel();
    this.isModalHidden = true;
    this.loadData = false;
    this.saveSuccess = false;
    this.loadAdditonalData = false;
  }

  loadEdit() {
    this.createButtonLoad = false;
    this.saveSuccess = false;
  }

  loadCreate() {
    this.createButtonLoad = true;
    // this.editButtonLoad = false;
    this.loadData = false;
    this.saveSuccess = false;
  }

  selectclient(value: any) {
    console.log(value);
  }

  redirect() {
    this._router.navigate(['./carrier-search']);
  }

  showTable() {
    this._clientService.GetListofSubscription(this.searchCriteria, this.searchText, this.entityStatus).subscribe((result) => {
      this.clientSearchResult = result;
      this.isviewTable = true;
      this.saveSuccess = false;
    });
  }

  getSelectedClientAssociatedCarriers() {
    this._clientService.GetCarriersListByPartyId(this.partyId).subscribe((result) => {
      this.associatedCarriersList = result;
      this.saveSuccess = false;
    });
  }

  loadClientData(index: number) {
    console.log(this.selectedParty);
    if (this.selectedParty !== undefined && this.selectedParty !== null) {
      this.loadAdditonalData = true;
      //this.account = this.clientDropdown[index];
      this.account = this.selectedParty;
      // console.log("ACCOUNT SELECTED");
      console.log(this.selectedParty);
      /*this._clientService.getPartyDropdown().subscribe((result) => {
        //this.clientDropdown = result;
        // this.editButtonLoad = false;
        this.loadAdditonalData = false;
        this.loadData = true;
        this.editClient = true;
        this.saveSuccess = false;
      });*/
    } else {
      this.showError('Select Client')
    }

  }

  loadFields(client: PartyInfo) {
    // this.cancel();
    this._clientService.checkPartyAvailability(client.PartyId)
      .subscribe((result) => {
        console.log('Party Exist');
        console.log(result);
        if (!result) {
          this.account.setSubscriptionId(client.SubscriptionId);
          this.account.setPartyId(client.PartyId);
          this.account.setPartyName(client.PartyName);
          this.account.setConsultancyStatus(ConsultancyStatus.NonConsultancy);
          this.editClient = false;
          this.loadData = true;
          this.loadAdditonalData = true;
        } else {
          this.showError('Party Already Exists')
        }
      })
  }

  editFields() {
    this.cancel();
    this._clientService.getPartyDropdown()
      .subscribe((result) => {
        console.log(result);
        this.clientDropdown = result;
        this.editClient = true;
        this.loadData = true;
      });
  }

  handleError(error) {
    console.log('Error Occured');
    console.log(error);
    this.showError('Some Error Occured, please report to support team along with steps to reproduce');
  }

  showSuccess(message: string) {
    //this.cancel();
    this.message = 'Client Details saved successfully';
    this.saveSuccess = true;
    this.isSuccess = true;
  }

  showError(message: string) {
    //this.cancel();
    this.isError = true;
    this.message = message;
  }

  // Save Record using http request

  saverecord() {
    if (this.account.Id) {
      this.updateAccount();
    } else {
      this.createAccount();
    }
    //document.body.scrollTop = 0;
    //document.documentElement.scrollTop = 0;
    // alert("Saved Successfully!!!");

  }




  updateAccount() {
    this._clientService.updateAccount(this.account)
      .subscribe((result) => {
        //this.cancel();
        if (result)
          this.showSuccess('Update user Completed');
        else
          this.showError('Update User failed');

      }, (error) => this.handleError(error));
  }

  createAccount() {
    console.log('Create Account');
    this._clientService.createAccount(this.account)
      .subscribe((result) => {
        console.log('Result');
        console.log(result);
        //this.cancel();
        if (result)
          this.showSuccess('Create user Completed');
        else
          this.showError('Create User failed');
      }, (error) => this.handleError(error));
  }

}
