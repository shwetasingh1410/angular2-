
export class RatingAgency {
    ratingAgencyId : number;
    ratingAgencyName : string;

    constructor(ratingAgencyId: number, ratingAgencyName: string) {
        this.ratingAgencyId=ratingAgencyId;
        this.ratingAgencyName=ratingAgencyName;
    }

    getRatingAgencyId(): number {
        return this.ratingAgencyId;
    }

    setRatingAgencyId(ratingAgencyId:number) {
     this.ratingAgencyId = ratingAgencyId;
    }

    getRatingAgencyName(): string {
        return this.ratingAgencyName;
    }

    setRatingAgencyName(ratingAgencyName:string) {
     this.ratingAgencyName = ratingAgencyName;
    }
}



export class RatingAgencyDisclaimer {
    id : number;
    ratingAgencyId : number;
    disclaimerText : string;
    isHidden : boolean;

    constructor(id : number, ratingAgencyId : number, disclaimerText : string, isHidden : boolean) {
        this.id=id;
        this.ratingAgencyId=ratingAgencyId;
        this.disclaimerText = disclaimerText;
        this.isHidden = isHidden;
    }

     getId(): number {
        return this.id;
    }

    setId(id:number) {
     this.id = id;
    }

     getRatingAgencyId(): number {
        return this.ratingAgencyId;
    }

    setRatingAgencyId(ratingAgencyId:number) {
     this.ratingAgencyId = ratingAgencyId;
    }

    getDisclaimerText(): string {
        return this.disclaimerText;
    }

    setDisclaimerText(disclaimerText:string) {
     this.disclaimerText = disclaimerText;
    }

    getIsHidden(): boolean {
        return this.isHidden;
    }

    setIsHidden(isHidden:boolean) {
     this.isHidden = isHidden;
    }
}

export class WTWDisclaimer {
    id : number;
    disclaimerText : string;
    isHidden : boolean;

     constructor(id : number, disclaimerText : string, isHidden : boolean) {
        this.id=id;
        this.disclaimerText = disclaimerText;
        this.isHidden = isHidden;
    }

     getId(): number {
        return this.id;
    }

    setId(id:number) {
     this.id = id;
    }
    
    getDisclaimerText(): string {
        return this.disclaimerText;
    }

    setDisclaimerText(disclaimerText:string) {
     this.disclaimerText = disclaimerText;
    }

    getIsHidden(): boolean {
        return this.isHidden;
    }

    setIsHidden(isHidden:boolean) {
     this.isHidden = isHidden;
    }

}