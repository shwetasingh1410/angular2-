import { Component, OnInit } from '@angular/core';
import { DisclaimersService } from './disclaimers.service';
import { RatingAgency, RatingAgencyDisclaimer, WTWDisclaimer } from './disclaimers.model';
//import $ from 'jQuery';
declare var $:any;
@Component({
  selector: 'app-disclaimers',
  templateUrl: './disclaimers.component.html',
  styleUrls: ['./disclaimers.component.css'],
  providers: [DisclaimersService]
})
export class DisclaimersComponent implements OnInit {
  text: string;
  wtwId: number;
  result: Array<RatingAgency>;
  disclaimerResult: RatingAgencyDisclaimer;
  WTWdisclaimerResult: WTWDisclaimer;
  constructor(private _disclaimerService:DisclaimersService) { 
    // this.text="Moody's Disclaimer";
  }

  ngOnInit() {
      // $.getScript('./assets/scripts/init.js');
       $.getScript('./assets/scripts/richTextEditor.js');
       this.GetRatingAgencies();
  }

  //Populate disclaimer with WTW disclaimer text
  GetDisclaimer() {
    this._disclaimerService.GetDisclaimer().subscribe(WTWdisclaimerResult => {
        this.WTWdisclaimerResult=WTWdisclaimerResult;
        $('#editor').html(WTWdisclaimerResult.disclaimerText);
        this.wtwId=WTWdisclaimerResult.id;
      });
  }

  //Get Rating Agency Dropdown
  GetRatingAgencies(){
    this._disclaimerService.GetRatingAgencies().subscribe(result => {
      console.log(result)
      this.result=result;
      this.GetDisclaimer();
  });
  }

  // Getting Disclaimer using RatingAgencyId
  GetDisclaimerByRatingAgencyId(id:number){
          $.getScript('./assets/scripts/richTextEditor.js');
          if(id != this.wtwId){   
         this._disclaimerService.GetDisclaimerByRatingAgencyId(id).subscribe(disclaimerResult => {
            $('#editor').html(disclaimerResult.disclaimerText);
  }); 
          }
          else {
            this.GetDisclaimer();
          }
    
}

saveData() {
 console.log($('#editor').html());
}

}

