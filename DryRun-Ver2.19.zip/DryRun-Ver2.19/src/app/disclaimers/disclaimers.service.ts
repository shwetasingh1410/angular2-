import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';

import { DisclaimersHelper } from './disclaimers.helper';
import { RatingAgency, RatingAgencyDisclaimer, WTWDisclaimer } from './disclaimers.model';
import { ratingAgencyDropdown } from './disclaimers.mock.data';


@Injectable()
export class DisclaimersService {
  constructor (
    private _http: Http
  ) {}

  GetRatingAgencies():Observable<Array<RatingAgency>> {
    return this._http.get('api/rating-agencies').map((response) => {
                let result: Array<RatingAgency> = new Array<RatingAgency>();
                response.json().forEach((agency) => {
                    result.push(DisclaimersHelper.mapToAgencyInfo(agency))
                });
                return result;
            });
  }

  GetDisclaimerByRatingAgencyId(ratingAgencyId:number):Observable<RatingAgencyDisclaimer> {
    return this._http.get('api/rating-agencies/disclaimers/'+ratingAgencyId)
            .map((response) => {
                let result:RatingAgencyDisclaimer;
                result=response.json();
                return result;
            })
  }

  GetDisclaimer():Observable<WTWDisclaimer> {
    return this._http.get('api/accounts/disclaimer')
            .map((response) => {
                let result:WTWDisclaimer;
                result=response.json();
                console.log("Disclaimer:");
                console.log(result);
                return result;
            })
  }

  PostDisclaimer(ratingAgencyId:number, RatingAgencyDisclaimer:RatingAgencyDisclaimer) {
     let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let options = new RequestOptions({ headers: headers });
        console.log('Create Disclaimer');
        return this._http.post('',
            JSON.stringify({
                'id' : RatingAgencyDisclaimer.id,
                'ratingAgencyId': RatingAgencyDisclaimer.ratingAgencyId,
                'disclaimerText': RatingAgencyDisclaimer.disclaimerText,
                'isHidden' : RatingAgencyDisclaimer.isHidden
            }), options).map((response) => response.json());
  }

  PutDisclaimer(id:number, ratingAgencyId:number ,UpdatedRatingAgencyDisclaimer:RatingAgencyDisclaimer) {
    let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let options = new RequestOptions({ headers: headers });
        return this._http.put('',
            JSON.stringify({
                'id' : UpdatedRatingAgencyDisclaimer.id,
                'ratingAgencyId': UpdatedRatingAgencyDisclaimer.ratingAgencyId,
                'disclaimerText': UpdatedRatingAgencyDisclaimer.disclaimerText,
                'isHidden' : UpdatedRatingAgencyDisclaimer.isHidden
            }), options).map((response) => response.json());
  }

}
