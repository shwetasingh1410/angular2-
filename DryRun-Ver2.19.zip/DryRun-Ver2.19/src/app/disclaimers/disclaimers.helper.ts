//will help in common utility static functions 
import { RatingAgency, RatingAgencyDisclaimer } from './disclaimers.model';
export class DisclaimersHelper {

    static mapToAgencyInfo(agency: any): RatingAgency {
        //return Agency Object
        return new RatingAgency(agency.ratingAgencyId,agency.ratingAgencyName);
    }

    static mapToDisclaimerInfo(disclaimer: any): RatingAgencyDisclaimer {
        //return Agency Object
        return new RatingAgencyDisclaimer(disclaimer.id, disclaimer.ratingAgencyId, disclaimer.disclaimerText, disclaimer.isHidden);
    }
    
}