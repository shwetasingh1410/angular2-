export const ratingAgencyDropdown = [
    {
        "AgencyName": "Moody's",
        "isHidden":false,
        "disclaimer":"You are visiting Moody's"
    },
    {
        "AgencyName": "S&P",
        "isHidden":false,
        "disclaimer":"You are visiting S&P's"
    },
    {
        "AgencyName": "Fitch",
        "isHidden":false,
        "disclaimer":"You are visiting Fitch's"
    },
    {
        "AgencyName": "A.M.Best",
        "isHidden":false,
        "disclaimer":"You are visiting A.M.Best's"
    },
    {
        "AgencyName": "WTW",
        "isHidden":false,
        "disclaimer":"You are visiting WTW's"
    }
];