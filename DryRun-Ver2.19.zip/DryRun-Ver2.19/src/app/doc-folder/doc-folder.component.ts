import { Component, OnInit } from '@angular/core';
//import $ from 'jquery';

@Component({
  selector: 'app-doc-folder',
  templateUrl: './doc-folder.component.html',
  styleUrls: ['./doc-folder.component.css']
})
export class DocFolderComponent implements OnInit {
  constructor() { }

  ngOnInit() {
      //$.getScript('./assets/scripts/init.js');
  }

}
