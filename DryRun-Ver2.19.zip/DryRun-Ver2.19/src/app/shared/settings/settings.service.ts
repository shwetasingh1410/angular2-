import { Injectable } from '@angular/core';
// import { environment } from '../../../environments/environment';

@Injectable()
export class Settings {

    private apiUrl: string;

    constructor() {
        // this.apiUrl = environment.apiUrl;
        this.apiUrl = (<any>window).apiUrl;
    }

    getApiUrl(): string {
        return this.apiUrl;
    }
}
