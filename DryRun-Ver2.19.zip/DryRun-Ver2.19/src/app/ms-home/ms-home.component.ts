import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ms-home',
  templateUrl: './ms-home.component.html',
  styleUrls: ['./ms-home.component.css']
})
export class MsHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
