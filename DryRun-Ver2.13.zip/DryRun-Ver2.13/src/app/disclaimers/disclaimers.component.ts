import { Component, OnInit } from '@angular/core';
//import $ from 'jQuery';
declare var $:any;
@Component({
  selector: 'app-disclaimers',
  templateUrl: './disclaimers.component.html',
  styleUrls: ['./disclaimers.component.css']
})
export class DisclaimersComponent implements OnInit {
  text: string;
  constructor() { 
    this.text="Moody's Disclaimer";
  }

  ngOnInit() {
      $.getScript('./assets/scripts/init.js');
  }

  reloadcontent(data){
    $.getScript('./assets/scripts/init.js');
    if(data=='S & P'){
      this.text="S & P Disclaimer";
    }
    if(data=="Moody's"){
      this.text="Moody's Disclaimer";
    }
    if(data=='Fitch'){
      this.text="Fitch Disclaimer";
    }
    if(data=='A.M.BEST'){
      this.text="A.M.BEST Disclaimer";
    }
  }

}
