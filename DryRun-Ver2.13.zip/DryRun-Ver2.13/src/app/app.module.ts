import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule, XHRBackend, RequestOptions, Http } from '@angular/http';

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { FooterComponent } from './footer/footer.component';
import { RatingsComponent } from './ratings/ratings.component';
import { routing } from './routing';
import { DisclaimersComponent } from './disclaimers/disclaimers.component';
import { EdituserComponent } from './edit-user/edituser.component';
import { AnnouncementsComponent } from './announcements/announcements.component';
import { CarriersearchComponent } from './carrier-search/carriersearch.component';
import { NotificationComponent } from './notification/notification.component';
import { CarrierDocComponent } from './carrier-doc/carrier-doc.component';
import { HomePageAdminComponent } from './home-page-admin/homepageAdmin.component';
import { CarrierfavoritesComponent } from './carrier-favorites/carrierfavorites.component';
import { ClientMaintenanceComponent } from './client-maintenance/clientmaintenance.component';
import { DocAccessComponent } from './doc-access/doc-access.component';
import { DocFolderComponent } from './doc-folder/doc-folder.component';
import { ReportsComponent } from './reports/reports.component';
import { MsHomeComponent } from './ms-home/ms-home.component';

// shared Modules
import { Settings } from './shared/settings/settings.service';
import { httpFactory } from './shared/http/http.factory'
import { NiceSelectDirective } from './shared/niceSelect/niceSelect';
import { LoaderComponent } from './shared/loaderComponent/loader.component';
import { LoaderService } from './shared/loaderComponent/Loader.service';
import { LoggedInUser } from './shared/loggedInUser/LoggedInUser';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    FooterComponent,
    RatingsComponent,
    DisclaimersComponent,
    EdituserComponent,
    AnnouncementsComponent,
    CarriersearchComponent,
    NotificationComponent,
    CarrierDocComponent,
    HomePageAdminComponent,
    CarrierfavoritesComponent,
    ClientMaintenanceComponent,
    DocAccessComponent,
    DocFolderComponent,
    ReportsComponent,
    MsHomeComponent,
    NiceSelectDirective,
    LoaderComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    routing
  ],
  providers: [
    Settings,
    LoaderService,
    LoggedInUser,
    {
      provide: Http,
      useFactory: httpFactory,
      deps: [XHRBackend, RequestOptions, Settings]
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
