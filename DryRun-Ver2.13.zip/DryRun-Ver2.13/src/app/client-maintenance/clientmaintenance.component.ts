import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Router } from '@angular/router';
//import $ from 'jquery';
import { ClientService } from './clientmaintenance.service';
import { LoggedInUser } from '../shared/loggedInUser/LoggedInUser';
import { PartyInfo, PartyDetails, AssociatedCarrier, Account, ConsultancyStatus, AccountAccess } from './clientmaintenance.model';
// import * as _ from "lodash";

@Component({
  selector: 'app-clientmaintenance',
  templateUrl: './clientmaintenance.component.html',
  styleUrls: ['./clientmaintenance.component.css'],
  providers: [ClientService, LoggedInUser]
})


export class ClientMaintenanceComponent implements OnInit {
  /* myQuote : any = {
     id: 1,
     quote: String,
     by: String
   }*/
  value: string;
  searchText: string;
  searchCriteria: string;
  entityStatus: string;
  partyId: number;
  AccountId: number;
  message: string;
  // isviewhidden=false;
  createButtonLoad = true;
  // editButtonLoad = false;
  isModalHidden = false;
  isviewTable = false;
  loadData = false;
  editClient: boolean;
  saveSuccess = false;
  loadAdditonalData = false;
  isError: boolean;
  isSuccess: boolean;

  //selectedClient: PartyDetails;
  clientSearchResult: Array<PartyInfo>;
  clientDropdown: Array<Account>;
  partiesList: Array<PartyDetails>;
  associatedCarriersList: Array<AssociatedCarrier>;
  account: Account;

  constructor(private _router: Router, private _clientService: ClientService, private _loggedInUser: LoggedInUser) {
    this.cancel();
  }


  cancel() {
    this.loadData = false;
    this.searchCriteria = "1";
    this.entityStatus = "1";
    this.searchText = null;
    this.editClient = false;
    //this.selectedClient = null;
    this.saveSuccess = false;
    this.loadAdditonalData = false;
    this.isError = false;
    this.isSuccess = false;
    this.isModalHidden = false;
    this.isviewTable = false;
    this.loadData = false;
    this.loadAdditonalData = false;
    this.account = new Account('', '', 0, '', ConsultancyStatus.NonConsultancy, true, AccountAccess.SuperUsersOnly, []);
    /*
        this.account = (this._loggedInUser.UserRole.Rank === 1) ? new Account('', '', 0, '', ConsultancyStatus.NonConsultancy, true, AccountAccess.SuperUsersOnly, [])
          :
          new Account('', '', 0, '', ConsultancyStatus.NonConsultancy, true, AccountAccess.AllAdmins, []);*/
  }

  resetSearchModal() {
    this.searchCriteria = "1";
    this.entityStatus = "1";
    this.searchText = null;
    this.saveSuccess = false;
  }

  ngOnInit() {
    // this.http.get('http://quotes.rest/qod').map((res : Response)=>{
    //   return res.json();
    // })
    // .catch((err: Response|any)=>{
    //   return Observable.throw(err.json());
    // }).subscribe((data)=>{      
    //   this.myQuote.quote = data.contents.quotes[0].quote; //set our myQuote Object
    //   this.myQuote.by = data.contents.quotes[0].author; //set our myQuote Object
    // }, (err)=>{
    //   console.log(err);
    //   this.myQuote.quote = "Error in fetching data"; //set our myQuote Object
    //   this.myQuote.by = "Error in fetching data"; //set our myQuote Object
    // });
  }


  loadModal() {
    // $.getScript('./assets/scripts/init.js');
    this.cancel();
    this.isModalHidden = true;
    this.loadData = false;
    //this.getClientsList();
    this.saveSuccess = false;
    this.loadAdditonalData = false;
  }

  loadEdit() {
    this.createButtonLoad = false;
    // this.editButtonLoad = true;
    this.saveSuccess = false;
  }

  loadCreate() {
    this.createButtonLoad = true;
    // this.editButtonLoad = false;
    this.loadData = false;
    this.saveSuccess = false;
  }
  /*
        loadFields() {
      this._clientService.GetPartyDropdown(this.searchText, this.entityStatus).subscribe((result) => {
        this.clientSearchResult = result;
        this.isviewTable = true;
        this.saveSuccess = false;
      });
        } */

  selectclient(value: any) {
    console.log(value);
    //this.selectedClient=this.partiesList[parseInt(value)];
  }

  // getClientsList() {
  //   this._clientService.getListOfParties().subscribe((result) => {
  //     this.partiesList = result;
  //         this.saveSuccess = false;
  //   });
  // }
  redirect() {
    this._router.navigate(['./carrier-search']);
  }

  /*
  showTable() {
    this._clientService.getclientSearchResult(this.searchText, this.entityStatus, this.searchCriteria).subscribe((result) => {
      this.clientSearchResult = result;
      this.isviewTable = true;
      this.saveSuccess = false;

    });
    getSelectedClientAssociatedCarriers() {
    this._clientService.getAssociatedCarriers().subscribe((result) => {
      this.associatedCarriersList = result;
          this.saveSuccess = false;
    });
  } 
    loadFields() {
    this._clientService.getAssociatedCarriers()
    //$.getScript('./assets/scripts/init.js');
    this.editButtonLoad = false;
    this.loadAdditonalData = false;
    this.loadData = true;
    this.getClientsList();
    this.editClient = true;
    this.saveSuccess = false;
  }
  loadClientData(){
 // $.getScript('./assets/scripts/init.js');
  this.loadAdditonalData =  true ; 
}
 */

  showTable() {
    this._clientService.GetListofSubscription(this.searchCriteria, this.searchText, this.entityStatus).subscribe((result) => {
      this.clientSearchResult = result;
      this.isviewTable = true;
      this.saveSuccess = false;
    });
  }

  getSelectedClientAssociatedCarriers() {
    this._clientService.GetCarriersListByPartyId(this.partyId).subscribe((result) => {
      this.associatedCarriersList = result;
      this.saveSuccess = false;
    });
  }

  loadClientData(index: number) {
    console.log(this.clientDropdown[index]);
    this.loadAdditonalData = true;
    this.account = this.clientDropdown[index];
    /*this._clientService.getPartyDropdown().subscribe((result) => {
      //this.clientDropdown = result;
      // this.editButtonLoad = false;
      this.loadAdditonalData = false;
      this.loadData = true;
      this.editClient = true;
      this.saveSuccess = false;
    });*/

  }

  loadFields(client: PartyInfo) {
   // this.cancel();
    this._clientService.checkPartyAvailability(client.PartyId)
      .subscribe((result) => {
        console.log('Party Exist');
        console.log(result);
        if (!result) {
          this.account.setSubscriptionId(client.SubscriptionId);
          this.account.setPartyId(client.PartyId);
          this.account.setPartyName(client.PartyName);
          this.account.setConsultancyStatus(ConsultancyStatus.NonConsultancy);
          this.editClient = false;
          this.loadData = true;
          this.loadAdditonalData = true;
        } else {
          this.showError('Party Already Exists!')
        }
      })


    /*
    this._clientService.GetAssociatedCarriers(this.AccountId).subscribe((result) => {
      this.associatedCarriersList = result;
      //this.editButtonLoad = false;
      this.loadAdditonalData = false;
      this.loadData = true;
      this.editClient = true;
      this.saveSuccess = false;
    });*/

  }

  editFields() {
    this.cancel();
    this._clientService.getPartyDropdown()
      .subscribe((result) => {
        console.log(result);
        this.clientDropdown = result;
        this.editClient = true;
        this.loadData = true;
      });
  }

  handleError(error) {
    console.log('Error Occured');
    console.log(error);
    this.showError('Some Error Occured, please report to support team along with steps to reproduce');
  }

  showSuccess(message: string) {
    //this.cancel();
    this.message = 'Client Details saved successfully';
    this.saveSuccess = true;
    this.isSuccess = true;
  }

  showError(message: string) {
    //this.cancel();
    this.isError = true;
    this.message = message;
  }

  // Save Record using http request

  saverecord() {
    if (this.account.Id) {
      this.updateAccount();
    } else {
      this.createAccount();
    }
    //document.body.scrollTop = 0;
    //document.documentElement.scrollTop = 0;
    // alert("Saved Successfully!!!");

  }




  updateAccount() {
    this._clientService.updateAccount(this.account)
      .subscribe((result) => {
        //this.cancel();
        if (result)
          this.showSuccess('Update user Completed');
        else
          this.showError('Update User failed');

      }, (error) => this.handleError(error));
  }

  createAccount() {
    console.log('Create Account');
    this._clientService.createAccount(this.account)
      .subscribe((result) => {
        console.log('Result');
        console.log(result);
        //this.cancel();
        if (result)
          this.showSuccess('Create user Completed');
        else
          this.showError('Create User failed');
      }, (error) => this.handleError(error));
  }

}
