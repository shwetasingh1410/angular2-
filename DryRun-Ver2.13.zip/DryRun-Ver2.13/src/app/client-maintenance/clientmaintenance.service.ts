import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';

import { environment } from '../../environments/environment';
import { CreateClientHelper } from './clientmaintenance.helper';
import { PartyInfo, PartyDetails, AssociatedCarrier, Account } from './clientmaintenance.model';
import { clientSearchResult, existingClientList, associatedCarriers } from './clientmaintenance.mock.data';

@Injectable()
export class ClientService {
    constructor(private _http: Http) {
    }
    /*testAPI(searchText: string, entityStatus: string, searchCriteria: string): Observable<Array<PartyInfo>> {
        return this._http.get('api/accounts/parties/'
            + searchCriteria + '/' + searchText + '/' + entityStatus)
            .map(response => {
                let result: Array<PartyInfo> = new Array<PartyInfo>();
                response.json().forEach((client) => {
                    result.push(CreateClientHelper.mapToPartyInfo(client));
                });
                return result;
            });
    }*/

    /* getclientSearchResult(searchText: string, entityStatus: string, searchCriteria: string) {
         let result: Array<PartyInfo> = new Array<PartyInfo>();
         //replace with service code
         clientSearchResult.forEach((client) => {
             result.push(CreateClientHelper.mapToPartyInfo(client));
         });
         return Observable.of(result);
     }*/

    // getListOfParties(): Observable<Array<PartyDetails>> {
    //     return this._http.get('api/accounts/active')
    //         .map((response) => {
    //             let result: Array<PartyDetails> = new Array<PartyDetails>();
    //             response.json().forEach(client => {
    //                 CreateClientHelper.mapToClientDetail(client);
    //             });
    //             return result;
    //         })
    // }

    // Search Result on 'Search a company' 
    GetListofSubscription(searchCriteria: string, searchText: string, entityStatus: string): Observable<Array<PartyInfo>> {
        return this._http.get('api/accounts/parties/' + searchCriteria + '/' + searchText + '/' + entityStatus)
            .map((response) => {
                let result: Array<PartyInfo> = new Array<PartyInfo>();
                response.json().forEach((client) => {
                    result.push(CreateClientHelper.mapToPartyInfo(client))
                });
                console.log('Subscription List');
                console.log(result);
                return result;
            });
    }
    // Get Carrier list by Party Id (Import functionality)
    GetCarriersListByPartyId(partyId: number): Observable<Array<AssociatedCarrier>> {
        return this._http.get('api/accounts/carriers/' + partyId)
            .map((response) => {
                let result: Array<AssociatedCarrier> = new Array<AssociatedCarrier>();
                response.json().forEach((client) => {
                    result.push(CreateClientHelper.mapToAssociatedCarrier(client))
                });
                return result;
            })
    }
    // Get Carrier List after ' Select Client' 
    GetAssociatedCarriers(AccountId: number): Observable<Array<AssociatedCarrier>> {
        return this._http.get('api/accounts/' + AccountId)
            .map((response) => {
                let result: Array<AssociatedCarrier> = new Array<AssociatedCarrier>();
                response.json().forEach((client) => {
                    result.push(CreateClientHelper.mapToAssociatedCarrier(client))
                });
                return result;
            })
    }
    // Party dropdown
    getPartyDropdown(): Observable<Array<Account>> {
        return this._http.get('api/accounts/active')
            .map((response) => {
                let result: Array<Account> = new Array<Account>();
                response.json().forEach((client) => {
                    result.push(CreateClientHelper.mapToAccount(client))
                });
                return result;
            })
    }
    //Creating Account Service
    createAccount(account: Account) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let options = new RequestOptions({ headers: headers });
        console.log('Create Account');
        // console.log(account);
        return this._http.post('api/accounts',
            JSON.stringify({
                'SubscriptionId': account.SubscriptionId,
                'PartyId': account.PartyId,
                'PartyName': account.PartyName,
                'ConsultancyStatus': account.ConsultancyStatus,
                'AccessLevel': account.AccessLevel,
                'AssociateAllCarriers': account.AssociateAllCarriers,
                'AssociatedCarriers': account.AssociatedCarriers
            }), options).map((response) => response.json());
        /*return this._http.post('api/accounts',
            JSON.stringify({
                "PartyId": 26,
                "PartyName": "Safari",
                "AccessLevel": 1,
                "ConsultancyStatus": 0,
                "AssociateAllCarriers": 0,
                "SubscriptionId": "e974b0ee-ef86-4242-916f-b417f2656672"

            }), options).map((response) => response.json());*/
    }
    updateAccount(account: Account) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let options = new RequestOptions({ headers: headers });
        return this._http.put('api/accounts/' + account.Id,
            JSON.stringify({
                'AccountName': account.PartyName,
                'ConsultancyStatus': account.ConsultancyStatus,
                'AccessLevel': account.AccessLevel,
                'AssociateAllCarriers': account.AssociateAllCarriers,
                'AssociatedCarriers': account.AssociatedCarriers
            }), options).map((response) => response.json());
    }

    checkPartyAvailability(PartyId: number) {
        return this._http.get('api/accounts/party/' + PartyId)
            .map((response) => response.json());
    }

}