//will help in common utility static functions 
import { PartyInfo, PartyDetails, AssociatedCarrier, Account } from './clientmaintenance.model';
export class CreateClientHelper {

    static mapToPartyInfo(client: any): PartyInfo {
        //return Client Object
        return new PartyInfo(client.SubscriptionId, client.PartyId, client.PartyName, client.Entity,
            client.Territory, client.Trading, client.MatchName);
    }
    static mapToPartyDetails(client: any): PartyDetails {
        return new PartyDetails(client.AccountId,client.PartyId, client.PartyName, client.ConsultancyStatus,
        client.AccessLevel)
    }

    static mapToAssociatedCarrier(carrier: any): AssociatedCarrier {
        return new AssociatedCarrier(carrier.AccountId, carrier.CarrierId, carrier.CarrierName,
            carrier.WTWCode, carrier.Comments, carrier.IsDefault);
    }
    static mapToAccount(party: any): Account {
        //console.log(party);
        return new Account(party.Id, party.SubscriptionId, party.PartyId, party.PartyName, party.ConsultancyStatus,
        party.AssociateAllCarriers, party.AccessLevel, party.AssociatedCarriers);
    }
}