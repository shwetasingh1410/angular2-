import { Component, Inject, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { DOCUMENT } from '@angular/platform-browser';
import { Router } from '@angular/router';
/*import {jQuery} from 'jquery';
declare var $:jQuery;*/
declare var $: any;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements AfterViewInit {
  @ViewChild('hoverElem') el: ElementRef;
  @ViewChild('activeme') el2: ElementRef;
  active = 'Market Security';
  passive = 'Market Security Admin';
  isAdminActive = false;
  isUserActive = true;
  dropdownOpen = false;
  url = 'url';
  headervalue;
  constructor( @Inject(DOCUMENT) private document: any, private _router: Router) {
    this.hitme();
  }


  ngAfterViewInit() {
    $('#hoverElem').hover(
      () => {
        $('.nav-vertical-submenu').addClass('active');
      },
      () => {
        $('.nav-vertical-submenu').removeClass('active');
      }
    );
    $('#activeme').hover(
      () => {
        $('.nav-vertical-submenu').addClass('active');
      },
      () => {
        $('.nav-vertical-submenu').removeClass('active');
      }
    );
  }

  menutoggle() {
    $('.navbar-toggler').toggleClass("opentime closedtime");
    $('.nav-mobile-text').toggleClass("hidden-sm-down hidden-sm-up");
  }


  hitme() {
    this.url = this.document.location.href;

    //console.log('matches ratings: '+this.url.endsWith('ratings'));
    if (this.url.endsWith('home')  || this.url.endsWith('carriersearch')  ||
      this.url.endsWith('notification') || this.url.endsWith('carrier-doc')) {
      this.passive = 'Market Security Admin';
      this.active = 'Market Security';
      this.isAdminActive = false;
      this.isUserActive = true;

    }
    else {
      this.active = 'Market Security Admin';
      this.passive = 'Market Security';
      this.isAdminActive = true;
      this.isUserActive = false;
    }

    if (this.url.endsWith('home') || this.url.endsWith('#') || this.url.endsWith('')) {
      this.headervalue = 'Welcome To Market Security';
    }

    if (this.url.endsWith('msHome')) {
      this.headervalue = 'Market Security Admin';
    }
    if (this.url.endsWith('disclaimers')) {
      this.headervalue = 'Disclaimers';
    }
    if (this.url.endsWith('ratings')) {
      this.headervalue = 'Rating Scale';
    }
    if (this.url.endsWith('edit-user')) {
      this.headervalue = 'User Maintenance';
    }
    if (this.url.endsWith('announcements')) {
      this.headervalue = 'Announcements';
    }
    if (this.url.endsWith('carrier-search')) {
      this.headervalue = 'Carrier Search';
    }
    if (this.url.endsWith('notification')) {
      this.headervalue = 'Client Notification';
    }
    if (this.url.endsWith('carrier-doc')) {
      this.headervalue = 'Client Documents';
    }
    if (this.url.endsWith('home-page-admin')) {
      this.headervalue = 'Home Page - Admin';
    }
    if (this.url.endsWith('carrier-favorites')) {
      this.headervalue = 'Carrier Favorites';
    }
    if (this.url.endsWith('client-maintenance')) {
      this.headervalue = 'Client Maintenance';
    }
    if (this.url.endsWith('doc-access')) {
      this.headervalue = 'Document Access';
    }
    if (this.url.endsWith('doc-folder')) {
      this.headervalue = 'Document Folder';
    }
    if (this.url.endsWith('reports')) {
      this.headervalue = 'Reports';
    }
    if (this.url.endsWith('superuseradmin')) {
      this.headervalue = 'Super User Admin';
    }
  }

  dropdownstatus() {
    this.dropdownOpen = !this.dropdownOpen;
  }

  activeComp(data) {
    if (data == 'Market Security Admin') {
      this.active = 'Market Security Admin';
      this.passive = 'Market Security';
      this.isAdminActive = true;
      this.isUserActive = false;
      this._router.navigate(['msHome']);
      this.headervalue = "Market Security Admin";
      window.location.reload();
    }
    else {
      this.passive = 'Market Security Admin';
      this.active = 'Market Security';
      this.isAdminActive = false;
      this.isUserActive = true;
      this._router.navigate(['home']);
      this.headervalue = "Welcome To Market Security";
      //window.location.reload();
    }
  }
  activeCompMob(data) {
    console.log(data);
    if (data == 'Market Security Admin') {
      this.active = 'Market Security Admin';
      this.passive = 'Market Security';
      this.isAdminActive = true;
      this.isUserActive = false;
      this._router.navigate(['msHome']);
      this.headervalue = "Market Security Admin";
    }
    else {
      this.passive = 'Market Security Admin';
      this.active = 'Market Security';
      this.isAdminActive = false;
      this.isUserActive = true;
      this._router.navigate(['home']);
      this.headervalue = "Welcome To Market Security";
    }
  }
}
