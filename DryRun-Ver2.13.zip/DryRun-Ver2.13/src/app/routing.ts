import { Router, RouterModule } from '@angular/router';

import { HomeComponent } from './home/home.component';
import { RatingsComponent } from './ratings/ratings.component';
import { DisclaimersComponent } from './disclaimers/disclaimers.component';
import { EdituserComponent } from './edit-user/edituser.component';
import { AnnouncementsComponent } from './announcements/announcements.component';
import { CarriersearchComponent } from './carrier-search/carriersearch.component';
import { NotificationComponent } from './notification/notification.component';
import { CarrierDocComponent } from './carrier-doc/carrier-doc.component';
import { HomePageAdminComponent } from './home-page-admin/homepageAdmin.component';
import { CarrierfavoritesComponent } from './carrier-favorites/carrierfavorites.component';
import { ClientMaintenanceComponent } from './client-maintenance/clientmaintenance.component';
import { DocAccessComponent } from './doc-access/doc-access.component';
import { DocFolderComponent } from './doc-folder/doc-folder.component';
import { ReportsComponent } from './reports/reports.component';
import { MsHomeComponent } from './ms-home/ms-home.component';


export const routing = RouterModule.forRoot([
    { path: 'home', component: HomeComponent },
    { path: 'disclaimers', component: DisclaimersComponent },
    { path: 'ratings', component: RatingsComponent },
    { path: 'edit-user', component: EdituserComponent },
    { path: 'announcements', component: AnnouncementsComponent },
    { path: 'carrier-search', component: CarriersearchComponent },
    { path: 'notification', component: NotificationComponent },
    { path: 'carrier-doc', component: CarrierDocComponent },
    { path: 'home-page-admin', component: HomePageAdminComponent },
    { path: 'carrier-favorites', component: CarrierfavoritesComponent },
    { path: 'client-maintenance', component: ClientMaintenanceComponent },
    { path: 'doc-access', component: DocAccessComponent },
    { path: 'doc-folder', component: DocFolderComponent },
    { path: 'reports', component: ReportsComponent },
    { path: 'msHome', component: MsHomeComponent },
    { path: '**', redirectTo: '\home' },
]);
