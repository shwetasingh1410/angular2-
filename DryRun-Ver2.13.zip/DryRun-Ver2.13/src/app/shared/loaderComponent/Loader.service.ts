﻿import { Injectable } from '@angular/core';

@Injectable()
export class LoaderService {
    private showLoader: boolean;
    private message: string;

    public show(message: string) {
        this.message = message;
        this.showLoader = true;
    }

    public hide() {
        this.showLoader = false
    }
}
