import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-carrier-doc',
  templateUrl: './carrier-doc.component.html',
  styleUrls: ['./carrier-doc.component.css']
})
export class CarrierDocComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
