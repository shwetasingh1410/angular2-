//will help in common utility static functions 
import { UserDetails, Account, Role, AccountActionIndicator } from './edituser.model';
export class EditUserHelper {

    static mapToUserDetails(user: any): UserDetails {
        //return User Object
        return new UserDetails(user.UserPrincipalId, user.UserType, user.UserStatus, user.Surname,
            user.Forename, user.Initials, user.EmailId, user.Country, user.Location,
            user.UserLogin);
    }

    static mapToAccount(userClient: any, action: AccountActionIndicator): Account {
        //return Account Object
        //console.log(userClient);
        return new Account(userClient.Id, userClient.PartyName, action);
    }

    static mapToRole(role: any): Role {
        return new Role(role.RoleId, role.RoleCode, role.RoleDescription, role.Rank);
    }


}