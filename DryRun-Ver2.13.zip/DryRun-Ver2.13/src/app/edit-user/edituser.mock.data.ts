export const accounts = [
    {
        "AccountId": 1,
        "AccountName": 'ABB Hongkong Limited (212323)',
        "ActionIndicator": 0
    },
    {
        "AccountId": 2,
        "AccountName": 'Swiss Life (Espana) (232342)',
        "ActionIndicator": 0
    },
    {
        "AccountId": 3,
        "AccountName": 'Farmers Insurance (453412)',
        "ActionIndicator": 0
    },
    {
        "AccountId": 4,
        "AccountName": 'Zenith Insurance (124512)',
        "ActionIndicator": 0
    },
    {
        "AccountId": 5,
        "AccountName": 'ABB Hongkong Limited1 (212323)',
        "ActionIndicator": 0
    },
    {
        "AccountId": 6,
        "AccountName": 'Swiss Life (Espana)1 (232342)',
        "ActionIndicator": 0
    },
    {
        "AccountId": 7,
        "AccountName": 'Farmers Insurance1 (453412)',
        "ActionIndicator": 0
    },
    {
        "AccountId": 8,
        "AccountName": 'Zenith Insurance1 (124512)',
        "ActionIndicator": 0
    }
];


export const userSearchResult = [
    {
        "UserPrincipalId": 102,
        "UserType": "1",
        "UserStatus": "1",
        "Surname": "Singh",
        "Forename": "Shweta",
        "Initials": "sh.singh",
        "EmailId": "shweta.singh@wtw.com",
        "Country": "India",
        "Location": "Pune",
        "UserLogin": "INT\\User1",
        "UserRole": 4,
        "AccountList": [

        ]
    },
    {
        "UserPrincipalId": 102,
        "UserType": "2",
        "UserStatus": "1",
        "Surname": "Pandey",
        "Forename": "Nilesh",
        "Initials": "py.nilesh",
        "EmailId": "nilesh.pandey@wtw.com",
        "Country": "India",
        "Location": "Mumbai",
        "UserLogin": "INT\\User2",
        "UserRole": 1,
        "AccountList": [
            {
                "AccountId": 1,
                "AccountName": 'ABB Hongkong Limited (212323)'
            },
            {
                "AccountId": 2,
                "AccountName": 'Swiss Life (Espana) (232342)'
            },
            {
                "AccountId": 3,
                "AccountName": 'Farmers Insurance (453412)'
            },
            {
                "AccountId": 4,
                "AccountName": 'Zenith Insurance (124512)'
            }
        ]
    },
    {
        "UserPrincipalId": 102,
        "UserType": "1",
        "UserStatus": "1",
        "Surname": "Singh",
        "Forename": "Satya",
        "Initials": "sh.satya",
        "EmailId": "satya.singh@wtw.com",
        "Country": "India",
        "Location": "Mumbai",
        "UserLogin": "INT\\User3",
        "UserRole": 2,
        "AccountList": [
            {
                "AccountId": 1,
                "AccountName": 'ABB Hongkong Limited (212323)'
            },
            {
                "AccountId": 2,
                "AccountName": 'Swiss Life (Espana) (232342)'
            },
            {
                "AccountId": 3,
                "AccountName": 'Farmers Insurance (453412)'
            },
            {
                "AccountId": 4,
                "AccountName": 'Zenith Insurance (124512)'
            }
        ]
    },
    {
        "UserPrincipalId": 102,
        "UserType": "2",
        "UserStatus": "1",
        "Surname": "Fernandes",
        "Forename": "Raisa",
        "Initials": "fs.raisa",
        "EmailId": "Raisa.Fernandes@wtw.com",
        "Country": "India",
        "Location": "Mumbai",
        "UserLogin": "INT\\User4",
        "UserRole": 3,
        "AccountList": [
            {
                "AccountId": 1,
                "AccountName": 'ABB Hongkong Limited (212323)'
            },
            {
                "AccountId": 2,
                "AccountName": 'Swiss Life (Espana) (232342)'
            },
            {
                "AccountId": 3,
                "AccountName": 'Farmers Insurance (453412)'
            },
            {
                "AccountId": 4,
                "AccountName": 'Zenith Insurance (124512)'
            }
        ]
    },
    {
        "UserPrincipalId": 102,
        "UserType": "1",
        "UserStatus": "1",
        "Surname": "Swati",
        "Forename": "jain",
        "Initials": "jn.swati",
        "EmailId": "swati.jain@wtw.com",
        "Country": "India",
        "Location": "Mumbai",
        "UserLogin": "INT\\User5",
        "UserRole": 3,
        "AccountList": [
            {
                "AccountId": 1,
                "AccountName": 'ABB Hongkong Limited (212323)'
            },
            {
                "AccountId": 2,
                "AccountName": 'Swiss Life (Espana) (232342)'
            },
            {
                "AccountId": 3,
                "AccountName": 'Farmers Insurance (453412)'
            },
            {
                "AccountId": 4,
                "AccountName": 'Zenith Insurance (124512)'
            }
        ]
    },
    {
        "UserPrincipalId": 102,
        "UserType": "2",
        "UserStatus": "2",
        "Surname": "Bansal",
        "Forename": "Abhishek",
        "Initials": "ab.bansal",
        "EmailId": "ab.bansal@wtw.com",
        "Country": "India",
        "Location": "Pune",
        "UserLogin": "INT\\User6",
        "UserRole": 3,
        "AccountList": [
            {
                "AccountId": 1,
                "AccountName": 'ABB Hongkong Limited (212323)'
            },
            {
                "AccountId": 2,
                "AccountName": 'Swiss Life (Espana) (232342)'
            },
            {
                "AccountId": 3,
                "AccountName": 'Farmers Insurance (453412)'
            },
            {
                "AccountId": 4,
                "AccountName": 'Zenith Insurance (124512)'
            }
        ]
    },
    {
        "UserPrincipalId": 102,
        "UserType": "1",
        "UserStatus": "2",
        "Surname": "Singh",
        "Forename": "Nitishkumar",
        "Initials": "sh.nitishkumar",
        "EmailId": "nitishkumar.singh@wtw.com",
        "Country": "India",
        "Location": "Mumbai",
        "UserLogin": "INT\\User7",
        "UserRole": 3,
        "AccountList": [
            {
                "AccountId": 1,
                "AccountName": 'ABB Hongkong Limited (212323)'
            },
            {
                "AccountId": 2,
                "AccountName": 'Swiss Life (Espana) (232342)'
            },
            {
                "AccountId": 3,
                "AccountName": 'Farmers Insurance (453412)'
            },
            {
                "AccountId": 4,
                "AccountName": 'Zenith Insurance (124512)'
            }
        ]
    },
    {
        "UserPrincipalId": 102,
        "UserType": "2",
        "UserStatus": "1",
        "Surname": "Singh",
        "Forename": "Shweta",
        "Initials": "sh.singh",
        "EmailId": "shweta.singh@wtw.com",
        "Country": "India",
        "Location": "Pune",
        "UserLogin": "INT\\Use27",
        "UserRole": 4,
        "AccountList": [
            {
                "AccountId": 1,
                "AccountName": 'ABB Hongkong Limited (212323)'
            },
            {
                "AccountId": 2,
                "AccountName": 'Swiss Life (Espana) (232342)'
            },
            {
                "AccountId": 3,
                "AccountName": 'Farmers Insurance (453412)'
            },
            {
                "AccountId": 4,
                "AccountName": 'Zenith Insurance (124512)'
            }
        ]
    },
    {
        "UserPrincipalId": 102,
        "UserType": "1",
        "UserStatus": "1",
        "Surname": "Pandey",
        "Forename": "Nilesh",
        "Initials": "py.nilesh",
        "EmailId": "nilesh.pandey@wtw.com",
        "Country": "India",
        "Location": "Mumbai",
        "UserLogin": "INT\\Use9r",
        "UserRole": 1,
        "AccountList": [
            {
                "AccountId": 1,
                "AccountName": 'ABB Hongkong Limited (212323)'
            },
            {
                "AccountId": 2,
                "AccountName": 'Swiss Life (Espana) (232342)'
            },
            {
                "AccountId": 3,
                "AccountName": 'Farmers Insurance (453412)'
            },
            {
                "AccountId": 4,
                "AccountName": 'Zenith Insurance (124512)'
            }
        ]
    },
    {
        "UserPrincipalId": 102,
        "UserType": "2",
        "UserStatus": "1",
        "Surname": "Singh",
        "Forename": "Satya",
        "Initials": "sh.satya",
        "EmailId": "satya.singh@wtw.com",
        "Country": "India",
        "Location": "Mumbai",
        "UserLogin": "INT\\Us8er",
        "UserRole": 2,
        "AccountList": [
            {
                "AccountId": 1,
                "AccountName": 'ABB Hongkong Limited (212323)'
            },
            {
                "AccountId": 2,
                "AccountName": 'Swiss Life (Espana) (232342)'
            },
            {
                "AccountId": 3,
                "AccountName": 'Farmers Insurance (453412)'
            },
            {
                "AccountId": 4,
                "AccountName": 'Zenith Insurance (124512)'
            }
        ]
    },
    {
        "UserPrincipalId": 102,
        "UserType": "1",
        "UserStatus": "1",
        "Surname": "Fernandes",
        "Forename": "Raisa",
        "Initials": "fs.raisa",
        "EmailId": "Raisa.Fernandes@wtw.com",
        "Country": "India",
        "Location": "Mumbai",
        "UserLogin": "INT\\Us6er",
        "UserRole": 3,
        "AccountList": [
            {
                "AccountId": 1,
                "AccountName": 'ABB Hongkong Limited (212323)'
            },
            {
                "AccountId": 2,
                "AccountName": 'Swiss Life (Espana) (232342)'
            },
            {
                "AccountId": 3,
                "AccountName": 'Farmers Insurance (453412)'
            },
            {
                "AccountId": 4,
                "AccountName": 'Zenith Insurance (124512)'
            }
        ]
    },
    {
        "UserPrincipalId": 102,
        "UserType": "2",
        "UserStatus": "1",
        "Surname": "Swati",
        "Forename": "jain",
        "Initials": "jn.swati",
        "EmailId": "swati.jain@wtw.com",
        "Country": "India",
        "Location": "Mumbai",
        "UserLogin": "INT\\Us3er",
        "UserRole": 3,
        "AccountList": [
            {
                "AccountId": 1,
                "AccountName": 'ABB Hongkong Limited (212323)'
            },
            {
                "AccountId": 2,
                "AccountName": 'Swiss Life (Espana) (232342)'
            },
            {
                "AccountId": 3,
                "AccountName": 'Farmers Insurance (453412)'
            },
            {
                "AccountId": 4,
                "AccountName": 'Zenith Insurance (124512)'
            }
        ]
    },
    {
        "UserPrincipalId": 102,
        "UserType": "1",
        "UserStatus": "2",
        "Surname": "Bansal",
        "Forename": "Abhishek",
        "Initials": "ab.bansal",
        "EmailId": "ab.bansal@wtw.com",
        "Country": "India",
        "Location": "Pune",
        "UserLogin": "INT\\Use1r",
        "UserRole": 3,
        "AccountList": [
            {
                "AccountId": 1,
                "AccountName": 'ABB Hongkong Limited (212323)'
            },
            {
                "AccountId": 2,
                "AccountName": 'Swiss Life (Espana) (232342)'
            },
            {
                "AccountId": 3,
                "AccountName": 'Farmers Insurance (453412)'
            },
            {
                "AccountId": 4,
                "AccountName": 'Zenith Insurance (124512)'
            }
        ]
    },
    {
        "UserPrincipalId": 102,
        "UserType": "1",
        "UserStatus": "2",
        "Surname": "Singh",
        "Forename": "Nitishkumar",
        "Initials": "sh.nitishkumar",
        "EmailId": "nitishkumar.singh@wtw.com",
        "Country": "India",
        "Location": "Mumbai",
        "UserLogin": "INT\Us2er",
        "UserRole": 3,
        "AccountList": [
            {
                "AccountId": 1,
                "AccountName": 'ABB Hongkong Limited (212323)'
            },
            {
                "AccountId": 2,
                "AccountName": 'Swiss Life (Espana) (232342)'
            },
            {
                "AccountId": 3,
                "AccountName": 'Farmers Insurance (453412)'
            },
            {
                "AccountId": 4,
                "AccountName": 'Zenith Insurance (124512)'
            }
        ]
    },
    {
        "UserPrincipalId": 102,
        "UserType": "1",
        "UserStatus": "1",
        "Surname": "Singh",
        "Forename": "Shweta",
        "Initials": "sh.singh",
        "EmailId": "shweta.singh@wtw.com",
        "Country": "India",
        "Location": "Pune",
        "UserLogin": "INT\\0User",
        "UserRole": 4,
        "AccountList": [
            {
                "AccountId": 1,
                "AccountName": 'ABB Hongkong Limited (212323)'
            },
            {
                "AccountId": 2,
                "AccountName": 'Swiss Life (Espana) (232342)'
            },
            {
                "AccountId": 3,
                "AccountName": 'Farmers Insurance (453412)'
            },
            {
                "AccountId": 4,
                "AccountName": 'Zenith Insurance (124512)'
            }
        ]
    },
    {
        "UserPrincipalId": 102,
        "UserType": "1",
        "UserStatus": "1",
        "Surname": "Pandey",
        "Forename": "Nilesh",
        "Initials": "py.nilesh",
        "EmailId": "nilesh.pandey@wtw.com",
        "Country": "India",
        "Location": "Mumbai",
        "UserLogin": "INT\\Use8r",
        "UserRole": 1,
        "AccountList": [
            {
                "AccountId": 1,
                "AccountName": 'ABB Hongkong Limited (212323)'
            },
            {
                "AccountId": 2,
                "AccountName": 'Swiss Life (Espana) (232342)'
            },
            {
                "AccountId": 3,
                "AccountName": 'Farmers Insurance (453412)'
            },
            {
                "AccountId": 4,
                "AccountName": 'Zenith Insurance (124512)'
            }
        ]
    },
    {
        "UserPrincipalId": 102,
        "UserType": "1",
        "UserStatus": "1",
        "Surname": "Singh",
        "Forename": "Satya",
        "Initials": "sh.satya",
        "EmailId": "satya.singh@wtw.com",
        "Country": "India",
        "Location": "Mumbai",
        "UserLogin": "INT\\0User",
        "UserRole": 2,
        "AccountList": [
            {
                "AccountId": 1,
                "AccountName": 'ABB Hongkong Limited (212323)'
            },
            {
                "AccountId": 2,
                "AccountName": 'Swiss Life (Espana) (232342)'
            },
            {
                "AccountId": 3,
                "AccountName": 'Farmers Insurance (453412)'
            },
            {
                "AccountId": 4,
                "AccountName": 'Zenith Insurance (124512)'
            }
        ]
    },
    {
        "UserPrincipalId": 102,
        "UserType": "1",
        "UserStatus": "1",
        "Surname": "Fernandes",
        "Forename": "Raisa",
        "Initials": "fs.raisa",
        "EmailId": "Raisa.Fernandes@wtw.com",
        "Country": "India",
        "Location": "Mumbai",
        "UserLogin": "INT\\6User",
        "UserRole": 3,
        "AccountList": [
            {
                "AccountId": 1,
                "AccountName": 'ABB Hongkong Limited (212323)'
            },
            {
                "AccountId": 2,
                "AccountName": 'Swiss Life (Espana) (232342)'
            },
            {
                "AccountId": 3,
                "AccountName": 'Farmers Insurance (453412)'
            },
            {
                "AccountId": 4,
                "AccountName": 'Zenith Insurance (124512)'
            }
        ]
    },
    {
        "UserPrincipalId": 102,
        "UserType": "1",
        "UserStatus": "1",
        "Surname": "Swati",
        "Forename": "jain",
        "Initials": "jn.swati",
        "EmailId": "swati.jain@wtw.com",
        "Country": "India",
        "Location": "Mumbai",
        "UserLogin": "INT\\7User",
        "UserRole": 3,
        "AccountList": [
            {
                "AccountId": 1,
                "AccountName": 'ABB Hongkong Limited (212323)'
            },
            {
                "AccountId": 2,
                "AccountName": 'Swiss Life (Espana) (232342)'
            },
            {
                "AccountId": 3,
                "AccountName": 'Farmers Insurance (453412)'
            },
            {
                "AccountId": 4,
                "AccountName": 'Zenith Insurance (124512)'
            }
        ]
    },
    {
        "UserPrincipalId": 102,
        "UserType": "1",
        "UserStatus": "2",
        "Surname": "Bansal",
        "Forename": "Abhishek",
        "Initials": "ab.bansal",
        "EmailId": "ab.bansal@wtw.com",
        "Country": "India",
        "Location": "Pune",
        "UserLogin": "INT\\U8ser",
        "UserRole": 3,
        "AccountList": [
            {
                "AccountId": 1,
                "AccountName": 'ABB Hongkong Limited (212323)'
            },
            {
                "AccountId": 2,
                "AccountName": 'Swiss Life (Espana) (232342)'
            },
            {
                "AccountId": 3,
                "AccountName": 'Farmers Insurance (453412)'
            },
            {
                "AccountId": 4,
                "AccountName": 'Zenith Insurance (124512)'
            }
        ]
    },
    {
        "UserPrincipalId": 102,
        "UserType": "1",
        "UserStatus": "2",
        "Surname": "Singh",
        "Forename": "Nitishkumar",
        "Initials": "sh.nitishkumar",
        "EmailId": "nitishkumar.singh@wtw.com",
        "Country": "India",
        "Location": "Mumbai",
        "UserLogin": "INT\\6User",
        "UserRole": 3,
        "AccountList": [
            {
                "AccountId": 1,
                "AccountName": 'ABB Hongkong Limited (212323)'
            },
            {
                "AccountId": 2,
                "AccountName": 'Swiss Life (Espana) (232342)'
            },
            {
                "AccountId": 3,
                "AccountName": 'Farmers Insurance (453412)'
            },
            {
                "AccountId": 4,
                "AccountName": 'Zenith Insurance (124512)'
            }
        ]
    },
    {
        "UserPrincipalId": 102,
        "UserType": "1",
        "UserStatus": "1",
        "Surname": "Singh",
        "Forename": "Shweta",
        "Initials": "sh.singh",
        "EmailId": "shweta.singh@wtw.com",
        "Country": "India",
        "Location": "Pune",
        "UserLogin": "INT\\Us7er",
        "UserRole": 4,
        "AccountList": [
            {
                "AccountId": 1,
                "AccountName": 'ABB Hongkong Limited (212323)'
            },
            {
                "AccountId": 2,
                "AccountName": 'Swiss Life (Espana) (232342)'
            },
            {
                "AccountId": 3,
                "AccountName": 'Farmers Insurance (453412)'
            },
            {
                "AccountId": 4,
                "AccountName": 'Zenith Insurance (124512)'
            }
        ]
    },
    {
        "UserPrincipalId": 102,
        "UserType": "1",
        "UserStatus": "1",
        "Surname": "Pandey",
        "Forename": "Nilesh",
        "Initials": "py.nilesh",
        "EmailId": "nilesh.pandey@wtw.com",
        "Country": "India",
        "Location": "Mumbai",
        "UserLogin": "INT\\U4ser",
        "UserRole": 1,
        "AccountList": [
            {
                "AccountId": 1,
                "AccountName": 'ABB Hongkong Limited (212323)'
            },
            {
                "AccountId": 2,
                "AccountName": 'Swiss Life (Espana) (232342)'
            },
            {
                "AccountId": 3,
                "AccountName": 'Farmers Insurance (453412)'
            },
            {
                "AccountId": 4,
                "AccountName": 'Zenith Insurance (124512)'
            }
        ]
    },
    {
        "UserPrincipalId": 102,
        "UserType": "1",
        "UserStatus": "1",
        "Surname": "Singh",
        "Forename": "Satya",
        "Initials": "sh.satya",
        "EmailId": "satya.singh@wtw.com",
        "Country": "India",
        "Location": "Mumbai",
        "UserLogin": "INT\\Us4er",
        "UserRole": 2,
        "AccountList": [
            {
                "AccountId": 1,
                "AccountName": 'ABB Hongkong Limited (212323)'
            },
            {
                "AccountId": 2,
                "AccountName": 'Swiss Life (Espana) (232342)'
            },
            {
                "AccountId": 3,
                "AccountName": 'Farmers Insurance (453412)'
            },
            {
                "AccountId": 4,
                "AccountName": 'Zenith Insurance (124512)'
            }
        ]
    },
    {
        "UserPrincipalId": 102,
        "UserType": "1",
        "UserStatus": "1",
        "Surname": "Fernandes",
        "Forename": "Raisa",
        "Initials": "fs.raisa",
        "EmailId": "Raisa.Fernandes@wtw.com",
        "Country": "India",
        "Location": "Mumbai",
        "UserLogin": "INT\\Use9r",
        "UserRole": 3,
        "AccountList": [
            {
                "AccountId": 1,
                "AccountName": 'ABB Hongkong Limited (212323)'
            },
            {
                "AccountId": 2,
                "AccountName": 'Swiss Life (Espana) (232342)'
            },
            {
                "AccountId": 3,
                "AccountName": 'Farmers Insurance (453412)'
            },
            {
                "AccountId": 4,
                "AccountName": 'Zenith Insurance (124512)'
            }
        ]
    },
    {
        "UserPrincipalId": 102,
        "UserType": "1",
        "UserStatus": "1",
        "Surname": "Swati",
        "Forename": "jain",
        "Initials": "jn.swati",
        "EmailId": "swati.jain@wtw.com",
        "Country": "India",
        "Location": "Mumbai",
        "UserLogin": "INT\\Use5r",
        "UserRole": 3,
        "AccountList": [
            {
                "AccountId": 1,
                "AccountName": 'ABB Hongkong Limited (212323)'
            },
            {
                "AccountId": 2,
                "AccountName": 'Swiss Life (Espana) (232342)'
            },
            {
                "AccountId": 3,
                "AccountName": 'Farmers Insurance (453412)'
            },
            {
                "AccountId": 4,
                "AccountName": 'Zenith Insurance (124512)'
            }
        ]
    },
    {
        "UserPrincipalId": 102,
        "UserType": "1",
        "UserStatus": "2",
        "Surname": "Bansal",
        "Forename": "Abhishek",
        "Initials": "ab.bansal",
        "EmailId": "ab.bansal@wtw.com",
        "Country": "India",
        "Location": "Pune",
        "UserLogin": "INT\\Us4er",
        "UserRole": 3,
        "AccountList": [
            {
                "AccountId": 1,
                "AccountName": 'ABB Hongkong Limited (212323)'
            },
            {
                "AccountId": 2,
                "AccountName": 'Swiss Life (Espana) (232342)'
            },
            {
                "AccountId": 3,
                "AccountName": 'Farmers Insurance (453412)'
            },
            {
                "AccountId": 4,
                "AccountName": 'Zenith Insurance (124512)'
            }
        ]
    },
    {
        "UserPrincipalId": 102,
        "UserType": "1",
        "UserStatus": "2",
        "Surname": "Singh",
        "Forename": "Nitishkumar",
        "Initials": "sh.nitishkumar",
        "EmailId": "nitishkumar.singh@wtw.com",
        "Country": "India",
        "Location": "Mumbai",
        "UserLogin": "INT\\2User",
        "UserRole": 3,
        "AccountList": [
            {
                "AccountId": 1,
                "AccountName": 'ABB Hongkong Limited (212323)'
            },
            {
                "AccountId": 2,
                "AccountName": 'Swiss Life (Espana) (232342)'
            },
            {
                "AccountId": 3,
                "AccountName": 'Farmers Insurance (453412)'
            },
            {
                "AccountId": 4,
                "AccountName": 'Zenith Insurance (124512)'
            }
        ]
    }
];

export const roles = [
    {
        "RoleId": "1",
        "RoleCode": 1,
        "RoleDescription": "Super Admin"
    },
    {
        "RoleId": "2",
        "RoleCode": 2,
        "RoleDescription": "MSD Admin"
    },
    {
        "RoleId": "3",
        "RoleCode": 3,
        "RoleDescription": "MSD BU Admin"
    },
    {
        "RoleId": "4",
        "RoleCode": 4,
        "RoleDescription": "WTW Reader"
    },
    {
        "RoleId": "5",
        "RoleCode": 5,
        "RoleDescription": "Client Reader"
    }
];